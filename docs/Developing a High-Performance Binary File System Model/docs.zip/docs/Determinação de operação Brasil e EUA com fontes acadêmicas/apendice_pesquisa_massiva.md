# Apêndice: Pesquisa Massiva Completa (16 Tópicos)

**Autor:** Manus AI
**Data:** 03 de Janeiro de 2026

Este documento contém todos os detalhes da pesquisa massiva realizada em 16 tópicos críticos de trading quantitativo.

---


## Tópico 1: Modelos de dimensionamento de posição (position sizing) ideais para trading quantitativo, com foco no Critério de Kelly (Kelly Criterion) e no dimensionamento fracionário fixo (fixed fractional).

### Fontes Principais

Ziemba, W. T., & MacLean, L. C. (2011). Using the Kelly Criterion for Investing. Link para PDF: https://webhomes.maths.ed.ac.uk/mckinnon/blackouts/StochOptFinanceAndEnergySpringer/Chap1_KellyZiemba.pdf
Vince, R. (1992). The Mathematics of Money Management: Risk Analysis Techniques for Traders. Link para PDF: https://archive.org/download/mathematics_202103/Mathematics%20Of%20Money%20Management.%20Ralph%20Vince.pdf
Wójtowicz, M., & Serwa, D. (2024). Application of Fractional Kelly Criterion to Enhance Profits in Emerging Markets. Link para PDF (SSRN Abstract): https://papers.ssrn.com/sol3/papers.cfm?abstract_id=5027918


### Parâmetros Vencedores (Ranges)

A literatura acadêmica e prática converge para a necessidade de aplicar uma **fração** do valor teórico ideal para mitigar a volatilidade de curto prazo e o risco de ruína, especialmente em mercados reais com estimativas de parâmetros imperfeitas [1] [2].

**1. Critério de Kelly (Kelly Criterion):**
*   **Fórmula:** $f^* = \frac{Bp - q}{B}$, onde $f^*$ é a fração ideal do capital a ser apostada/investida.
    *   $p$: Probabilidade de ganho.
    *   $q$: Probabilidade de perda ($1-p$).
    *   $B$: Razão entre o ganho líquido e a perda (Payoff Ratio).
*   **Parâmetro Vencedor (Regra de Ouro):** **Fractional Kelly** (Kelly Fracionário).
    *   **Range Recomendado:** **$f_{frac} = \frac{1}{2}f^*$ (Half-Kelly) a $\frac{1}{4}f^*$ (Quarter-Kelly)** [1].
    *   **Justificativa:** O *Full Kelly* ($f^*$) maximiza o crescimento geométrico de longo prazo, mas é extremamente arriscado no curto prazo, levando a grandes *drawdowns* (quedas) e alta probabilidade de perdas significativas [1]. O *Half-Kelly* oferece um crescimento muito próximo do máximo com uma redução substancial na volatilidade e no risco de ruína.

**2. Optimal f (Ralph Vince):**
*   **Conceito:** A fração do capital que maximiza a Média Geométrica (Geometric Mean) dos retornos, aplicada a sistemas de trading com distribuições de P&L (Lucro e Prejuízo) complexas.
*   **Parâmetro Vencedor (Regra de Ouro):** **Secure Optimal f** (Optimal f Seguro).
    *   **Range Recomendado:** O valor de $f$ que oferece a maior Média Geométrica, mas que é ajustado para um nível de *drawdown* aceitável (e.g., $f$ que limita o *drawdown* máximo a 20-30%) [2].
    *   **Justificativa:** O *Optimal f* é extremamente sensível ao maior prejuízo (*largest loss*) do sistema. Em sistemas reais, o *Optimal f* pode ser muito alto, levando a um risco de ruína inaceitável. O **Secure Optimal f** é a versão prática e fracionária do conceito, focada em gerenciar o risco de cauda e o *drawdown* [2].

**3. Fixed Fractional (Regra Simples de Risco):**
*   **Parâmetro Vencedor (Regra de Ouro):** Risco máximo por transação.
    *   **Range Recomendado:** **1% a 2% do capital total por transação**.
    *   **Justificativa:** Para a maioria dos sistemas de trading, especialmente aqueles com um Z-score entre 2 e 3.5, a literatura sugere que o risco por transação não deve exceder 2% do capital. Esta regra simples é um método de *position sizing* conservador que evita o risco de ruína e é frequentemente usado como um limite superior de risco, mesmo em estratégias Kelly/Optimal f [1].


### Diferenças Brasil vs EUA

**Comparação Estruturada: Mercados Desenvolvidos (EUA) vs. Emergentes (Brasil)**

| Característica | Mercados Desenvolvidos (EUA) | Mercados Emergentes (Brasil) | Implicação para Sizing |
| :--- | :--- | :--- | :--- |
| **Volatilidade** | Geralmente menor. | Geralmente maior (maior risco de cauda). | Aumenta a necessidade de **Fractional Kelly** para mitigar o risco de ruína. |
| **Liquidez** | Alta e consistente. | Variável, com menor liquidez em ativos específicos. | O *Optimal f* pode ser menos estável e a execução de grandes posições mais difícil. |
| **Distribuição de Retornos** | Mais próxima da normal (embora com caudas gordas). | Mais propensa a distribuições não-normais e *fat tails* (caudas gordas). | O Kelly/Optimal f puro (que assume normalidade ou independência) é mais perigoso; o uso de **Secure Optimal f** ou **Fractional Kelly** é imperativo [2]. |
| **Estudo Específico (Wójtowicz & Serwa, 2024)** | N/A (foco em mercados emergentes). | O estudo confirmou a vantagem do *Fractional Kelly Criterion* sobre a gestão de capital simples para o índice agregado de mercados emergentes e para o índice da China. Embora o índice do Brasil tenha sido analisado (2002-2021), o resumo não detalha os resultados específicos, mas a conclusão geral suporta a aplicação de métodos de *sizing* ajustados ao risco [3]. | O princípio de que a gestão de capital baseada em *Fractional Kelly* é superior se aplica ao Brasil, dada a sua classificação como mercado emergente. |

**Conclusão:** A maior volatilidade e o risco de cauda (*fat tails*) nos mercados emergentes, como o Brasil, tornam a aplicação do **Fractional Kelly Criterion** (tipicamente **Half-Kelly** ou menos) uma regra de ouro ainda mais crítica do que nos mercados desenvolvidos, onde o *Full Kelly* já é considerado excessivamente arriscado [1]. A sensibilidade do *Optimal f* ao maior prejuízo (*largest loss*) exige uma margem de segurança maior (menor fração) no Brasil [2].


---


## Tópico 2: Pesquisa acadêmica sobre o cálculo e controle do Risco de Ruína (RoR) e a aplicação de parâmetros de dimensionamento de posição, como o Kelly Criterion e o Optimal f, no contexto de gestão de portfólio e trading quantitativo.

### Fontes Principais

Vince, R. (1992). The Mathematics of Money Management: Risk Analysis Techniques for Traders. John Wiley & Sons. Link para PDF: N/A (Livro, não há link direto para PDF acadêmico)
Ziemba, W. T., & MacLean, L. C. (2011). Using the Kelly Criterion for Investing. In Stochastic Optimization Models in Finance (pp. 3-36). Springer. Link para PDF: https://webhomes.maths.ed.ac.uk/mckinnon/blackouts/StochOptFinanceAndEnergySpringer/Chap1_KellyZiemba.pdf
Chamness, D. E. (2009). Minimizing Your Risk Of Ruin. Futures Magazine, August 2009. Link para PDF: https://www3.gmu.edu/schools/vse/seor/studentprojects/graduate/2009Fall/ISG/Investment_Optimization/Resources_files/Risk_of_ruin.pdf
Thorp, E. O. (2006). The Kelly Criterion in Blackjack, Sports Betting, and the Stock Market. The American Mathematical Monthly, 113(1), 1-28. Link para PDF: https://gwern.net/doc/statistics/decision/2006-thorp.pdf


### Parâmetros Vencedores (Ranges)

O principal parâmetro de controle do Risco de Ruína (RoR) na literatura de trading quantitativo é a **fração de capital a ser alocada por trade**, derivada do **Kelly Criterion** ($f^*$) ou do **Optimal f** (conceito popularizado por Ralph Vince).

| Parâmetro | Range Recomendado | Justificativa |
| :--- | :--- | :--- |
| **Fração Kelly ($f_{frac}$)** | **1/2 Kelly (50% de $f^*$)** | Reduz o RoR e a volatilidade de curto prazo, mantendo 75% da taxa de crescimento de longo prazo do Kelly completo. É o padrão mais aceito para aversão ao risco e robustez a erros de estimativa [2]. |
| **Fração Kelly ($f_{frac}$)** | **1/4 Kelly (25% de $f^*$)** | Recomendado para estratégias com alta incerteza nos parâmetros de entrada (probabilidade de ganho e *payoff*), ou em mercados de alta volatilidade (como o Brasil), minimizando o risco de *drawdown* [2]. |
| **Risco de Ruína (RoR) Alvo** | **< 1%** | A literatura de gestão de risco em trading sugere que um RoR aceitável deve ser inferior a 1% para a vida útil da estratégia. O RoR é inversamente proporcional à razão entre retorno médio e desvio padrão [3]. |
| **Máximo Drawdown (MDD)** | **< 20%** | Embora não seja um parâmetro de cálculo de RoR, o MDD é a métrica de controle mais observada. A alocação de capital deve ser ajustada para que o MDD histórico e simulado permaneça abaixo de 20% para a maioria dos investidores [1]. |

**Fórmula de Kelly (para um único ativo):**
$$f^* = \frac{p \cdot W - q \cdot L}{W \cdot L}$$
Onde:
*   $f^*$ = Fração ótima do capital a ser apostada.
*   $p$ = Probabilidade de ganho.
*   $q$ = Probabilidade de perda ($1-p$).
*   $W$ = Ganho médio por trade.
*   $L$ = Perda média por trade.

**Regra de Ouro:** Nunca utilizar o $f^*$ completo, pois ele implica em um risco de ruína de 1 (ou seja, a ruína é certa no longo prazo devido à volatilidade) [2]. A utilização de **Fractional Kelly** é o principal parâmetro vencedor para o controle do RoR.


### Diferenças Brasil vs EUA

A principal diferença reside na **liquidez** e **volatilidade** dos mercados. O mercado dos EUA (NYSE, NASDAQ) é significativamente mais líquido e profundo que o mercado brasileiro (B3), o que permite a execução de estratégias quantitativas de alta frequência e grande volume com menor *slippage*.
*   **Liquidez e Tamanho do Mercado:** O mercado de capitais dos EUA é vastamente maior. A maior liquidez e o maior número de ativos negociados reduzem o risco de ruína induzido por incapacidade de fechar posições ou por grandes variações de preço devido a ordens grandes.
*   **Volatilidade e Risco:** O mercado brasileiro (B3) é historicamente mais volátil devido a fatores macroeconômicos e políticos internos. Essa maior volatilidade exige que os parâmetros de controle de RoR (como o *f* fracionário) sejam mais conservadores no Brasil para manter o mesmo nível de probabilidade de ruína.
*   **Custos Transacionais:** Embora os custos de corretagem tenham diminuído globalmente, os custos implícitos (como o *spread* bid-ask) tendem a ser maiores em ativos de menor liquidez na B3, o que impacta negativamente a rentabilidade de estratégias de alta frequência e, consequentemente, aumenta o risco de ruína.
*   **Dados:** Nos EUA, o acesso a dados de alta qualidade (tick-by-tick, *order book*) é mais padronizado e acessível (e.g., base de dados TAQ). No Brasil, o acesso a dados de alta frequência pode ser mais custoso e fragmentado, o que dificulta a calibração precisa dos modelos de RoR.
*   **Conclusão para RoR:** Para o Brasil, a calibração do *f* fracionário deve ser mais conservadora (e.g., 1/4 Kelly) e o modelo de RoR deve incorporar um *buffer* maior para volatilidade e *slippage* do que o aplicado em mercados desenvolvidos.


---


## Tópico 3: Estratégias de controle de Drawdown e recuperação em trading algorítmico, com foco em parâmetros numéricos e diferenças de implementação entre mercados.

### Fontes Principais

Alexei Chekhlov, Stanislav Uryasev, & Michael Zabarankin (2003). Portfolio Optimization with Drawdown Constraints. Link para PDF: https://www.cis.upenn.edu/~mkearns/finread/drawdown.pdf
Ernest P. Chan (2013). Algorithmic Trading: Winning Strategies and Their Rationale. Link para PDF: https://dl.najafi8.ir/dl/Library/book/Algorithmic_Trading__Winning_Strategies.pdf
Chung-Han Hsieh, & B. Ross Barmish (2017). On Drawdown-Modulated Feedback Control in Stock Trading. Link para PDF: https://arxiv.org/pdf/1710.01503
Rui Ding, & Stan Uryasev (2022). Drawdown beta and portfolio optimization. Link para PDF: http://uryasev.ams.stonybrook.edu/wp-content/uploads/2022/02/Drawdown_beta_and_portfolio_optimization.pdf


### Parâmetros Vencedores (Ranges)

A literatura acadêmica e de mercado sugere a adoção de parâmetros numéricos e ranges estritos para a gestão de *drawdown* (MDD - Maximum Drawdown) e o tempo de recuperação (*Drawdown Duration*).

| Parâmetro | Range Recomendado | Justificativa e Regra de Ouro |
| :--- | :--- | :--- |
| **Maximum Drawdown (MDD)** | **10% a 25%** | **Regra de Ouro:** Um MDD aceitável para estratégias quantitativas de longo prazo e multi-ativos geralmente fica abaixo de 25% [5]. Para fundos de hedge e estratégias de alta frequência, o limite é frequentemente mais apertado, em torno de 10% a 15%. O limite deve ser definido como um **stop-loss de estratégia** que, se atingido, dispara uma revisão ou desativação do algoritmo. |
| **Conditional Drawdown-at-Risk (CDaR)** | **Variável (Ex: 95% ou 99%)** | O CDaR [1] é a média dos piores *drawdowns* (ex: os 5% piores). O parâmetro de tolerância ($\alpha$) deve ser escolhido para refletir o apetite a risco. Otimizar o portfólio com base no CDaR tende a produzir portfólios mais estáveis e robustos do que apenas o MDD. |
| **Drawdown Duration (Tempo de Recuperação)** | **< 12 meses** | O tempo de recuperação é o período para que o capital retorne ao pico anterior. Estratégias vencedoras devem ter um *recovery time* significativamente menor que o horizonte de investimento do cliente. Um tempo de recuperação superior a 12-18 meses é frequentemente considerado um sinal de alerta para a ineficácia da estratégia. |
| **Kelly Criterion (Fração de Aposta)** | **f < 1 (fração conservadora)** | A Kelly Criterion é usada para dimensionar o tamanho da aposta (posição) [2]. Embora a Kelly completa maximize o crescimento logarítmico, ela é extremamente arriscada. A literatura recomenda usar uma **fração de Kelly** (ex: $f/2$ ou $f/4$) para reduzir a volatilidade e o *drawdown* em troca de um crescimento ligeiramente menor, mas mais seguro. |
| **Drawdown-Modulated Feedback Control** | **Limite de *Drawdown* (dmax)** | Esta técnica [3] ajusta o tamanho da posição em tempo real com base no *drawdown* atual. O parâmetro $d_{max}$ (o limite máximo de *drawdown* tolerado) é o principal parâmetro de controle. A regra de ouro é reduzir a exposição à medida que o *drawdown* se aproxima de $d_{max}$, e aumentá-la durante a recuperação. |
| **Recovery Factor** | **> 1** | Definido como (Lucro Líquido Total / MDD). Um fator de recuperação maior que 1 indica que a estratégia gerou mais lucro do que perdeu no seu pior momento. Estratégias robustas buscam um fator de recuperação significativamente maior (ex: > 3). |


### Diferenças Brasil vs EUA

A diferença de implementação entre os mercados desenvolvido (EUA) e emergente (Brasil) reside principalmente na **estrutura de mercado** e **liquidez**.
*   **Liquidez e Profundidade de Mercado:** O mercado dos EUA (NYSE, NASDAQ) é significativamente mais líquido e profundo. Isso permite que algoritmos de trading de alta frequência (HFT) e estratégias de execução de grande volume operem com menor *market impact* (impacto no preço) e, consequentemente, com menor risco de *drawdown* induzido pela própria execução. No Brasil (B3), a menor liquidez em muitos ativos (exceto os mais negociados) exige que os algoritmos de controle de *drawdown* sejam mais conservadores, utilizando limites de volume e tempo mais estritos para evitar a deterioração do preço de execução.
*   **Volatilidade e Regimes de Mercado:** Mercados emergentes como o Brasil tendem a apresentar maior **volatilidade** e mudanças mais abruptas nos regimes de mercado, muitas vezes influenciadas por fatores políticos e macroeconômicos locais. Isso implica que as estratégias de controle de *drawdown* no Brasil devem incorporar mecanismos de **adaptação de risco** mais rápidos, como o *Drawdown-Modulated Feedback Control* [3], ajustando o tamanho da posição (Kelly Criterion) ou a exposição de forma mais dinâmica.
*   **Regulamentação e Custos:** Embora ambos os mercados tenham regulamentação robusta, o custo de transação e a estrutura de impostos podem variar, afetando a rentabilidade líquida e, indiretamente, o tempo de recuperação (*recovery time*) de um *drawdown*.
*   **Conclusão:** Enquanto nos EUA o foco está na otimização de estratégias complexas com alta liquidez, no Brasil, o controle de *drawdown* deve priorizar a **resiliência** a choques de liquidez e a **gestão de risco** em ambientes de alta volatilidade e menor profundidade de mercado.


---


## Tópico 4: Pesquisa acadêmica aprofundada sobre a estratégia de *Volatility Targeting* (Alvo de Volatilidade), focando em níveis ótimos de volatilidade alvo, regras de ajuste de alavancagem e diferenças de implementação entre mercados desenvolvidos (EUA) e emergentes (Brasil).

### Fontes Principais

Harvey, Campbell R., Hoyle, Edward, Korgaonkar, Russell, Rattray, Sandy, Sargaison, Matthew, & Van Hemert, Otto (2018). The Impact of Volatility Targeting. The Journal of Portfolio Management, 45(1), 14-33. Link para PDF: https://people.duke.edu/~charvey/Research/Published_Papers/P135_The_impact_of.pdf
Moreira, Alan, & Muir, Tyler (2017). Volatility-Managed Portfolios. The Journal of Finance, 72(4), 1613-1645. Link para PDF: https://amoreira2.github.io/alan-moreira.github.io/VolPortfolios_published.pdf
Lopes, Maria Eduarda Constantino (2025). Sistemas híbridos para previsão de volatilidade em investimentos: GARCH e MLP no mercado brasileiro. Trabalho de Conclusão de Curso (Graduação), Universidade Federal da Paraíba (UFPB). Link para PDF: https://repositorio.ufpb.br/jspui/bitstream/123456789/36357/1/MECL16102025.pdf


### Parâmetros Vencedores (Ranges)

A literatura acadêmica converge em torno de um conjunto de **"regras de ouro"** e **ranges de parâmetros** para a implementação eficaz do *Volatility Targeting* em estratégias de *quantitative trading*:

**1. Nível Ótimo de Volatilidade Alvo (Target Volatility - $\sigma_{target}$):**
*   **Range Recomendado:** A literatura de *asset management* e *quantitative finance* sugere um range comum de **8% a 15% anualizado** para portfólios de risco moderado a alto [1].
*   **Parâmetro Vencedor:** O estudo seminal de Harvey et al. (2018) utiliza e valida um alvo de **10% anualizado** para facilitar a comparação entre diferentes ativos e estratégias, demonstrando que o benefício da estratégia se mantém robusto em torno deste nível [1].
*   **Justificativa:** O nível alvo deve ser escolhido com base no apetite de risco do investidor e nas restrições de alavancagem. Um alvo de 10% a 15% é frequentemente escolhido por equilibrar a redução de *drawdown* com a manutenção de retornos robustos.

**2. Regra de Ajuste de Alavancagem (Leverage Adjustment Rule):**
*   **Fórmula Base:** A regra fundamental é ajustar a exposição (alocação $w_t$) de forma **inversamente proporcional** à volatilidade prevista ($\sigma_{t-1}$) [1] [2].
    $$w_t = w_{original} \times \frac{\sigma_{target}}{\sigma_{t-1}}$$
    *Onde:* $w_{original}$ é a alocação base (e.g., 1 para um portfólio 100% alocado), $\sigma_{target}$ é a volatilidade alvo (e.g., 10% anualizado), e $\sigma_{t-1}$ é a volatilidade prevista para o próximo período.
*   **Variação (Variância):** Moreira e Muir (2017) demonstram que escalar pela **variância** ($\sigma^2$) em vez do desvio padrão ($\sigma$) também é altamente eficaz, especialmente para investidores *mean-variance* [2].
    $$w_t \propto \frac{k}{\sigma_{t-1}^2}$$
*   **Regra de Ouro:** A alavancagem deve ser **reduzida** quando a volatilidade prevista for **maior** que o alvo ($\sigma_{t-1} > \sigma_{target}$) e **aumentada** (alavancada) quando for **menor** ($\sigma_{t-1} < \sigma_{target}$).

**3. Estimativa de Volatilidade (Volatility Estimation):**
*   **Parâmetros Comuns (EUA):** O uso de **pesos exponencialmente decrescentes (EWMA)** sobre retornos diários é um método padrão, com um período de *warm-up* de **270 dias** para garantir a estabilidade da estimativa [1]. A **Variância Realizada Mensal** também é um método robusto [2].
*   **Parâmetros Críticos (Brasil):** Em mercados emergentes com alta volatilidade e não linearidades, modelos **GARCH** ou **Híbridos GARCH-MLP** são recomendados para maior precisão na previsão da volatilidade condicional, o que é crucial para a eficácia da estratégia [3].

**4. Frequência de Rebalanceamento:**
*   **Range Recomendado:** O rebalanceamento é tipicamente realizado em frequência **diária** (para estimativa de volatilidade) e **mensal** (para ajuste de alocação), embora a literatura sugira que o benefício do *volatility targeting* se mantém mesmo com rebalanceamentos menos frequentes [1] [2].

**Resumo da Regra de Ouro:** O sucesso da estratégia reside na capacidade de **prever a volatilidade com precisão** e **ajustar a exposição de forma contrária** à volatilidade prevista, mantendo o risco do portfólio constante em um nível alvo (e.g., 10% anualizado). Este ajuste dinâmico melhora o Sharpe Ratio e reduz o *drawdown* máximo.


### Diferenças Brasil vs EUA

**Comparação Estruturada: Volatility Targeting em Mercados Desenvolvidos (EUA) vs. Emergentes (Brasil)**

| Característica | Mercados Desenvolvidos (EUA) | Mercados Emergentes (Brasil) |
| :--- | :--- | :--- |
| **Volatilidade Média** | Historicamente mais baixa e estável (e.g., S&P 500 com média histórica de ~15% anualizada) [1]. | Historicamente mais alta e sujeita a **episódios recorrentes de alta volatilidade** e dinâmicas não lineares [3]. |
| **Modelos de Previsão** | Modelos mais simples como **EWMA (Exponentially Weighted Moving Average)** ou **Variância Realizada (Realized Variance)** do mês anterior são amplamente utilizados e servem como *benchmark* [1] [2]. | Modelos mais sofisticados, como **GARCH** ou **Sistemas Híbridos (GARCH + Machine Learning como MLP)**, são sugeridos para capturar a heterocedasticidade e os padrões não lineares, essenciais para uma previsão mais precisa [3]. |
| **Foco da Estratégia** | Maior foco na **melhoria do Sharpe Ratio** e na redução do *drawdown* máximo em portfólios multi-ativos (ações, títulos, commodities) [1] [2]. | Maior foco na **cobertura de picos e caudas** (melhor QLIKE), devido ao risco de *tail events* mais frequentes. O GARCH atua como âncora de calibração, e o MLP/Híbrido oferece maior reatividade [3]. |
| **Regra de Alavancagem** | Ajuste de exposição (alavancagem) tipicamente **inversamente proporcional à volatilidade (ou variância) estimada** [1] [2]. | A regra é a mesma, mas a **frequência e a magnitude do ajuste** podem ser mais críticas devido à volatilidade mais alta e mais volátil (volatilidade da volatilidade) [3]. |
| **Alocação** | Eficácia comprovada em **ativos de risco** (ações, crédito) e portfólios que os contêm (60/40, *risk parity*) [1]. | A estratégia é crucial para a gestão de risco em índices locais (e.g., IBOV, IBRX100), onde a volatilidade é um fator dominante [3]. |

**Conclusão:** A principal diferença reside na **complexidade do modelo de previsão de volatilidade** necessário. Enquanto nos EUA modelos mais simples são robustos, no Brasil, a natureza do mercado exige modelos mais avançados para garantir a eficácia do *volatility targeting* na gestão de risco.


---


## Tópico 5: VaR vs. CVaR/Expected Shortfall para gestão diária de risco em trading quantitativo, com foco em parâmetros numéricos e diferenças de implementação entre mercados.

### Fontes Principais

Yamai, Yasuhiro; Yoshiba, Toshinao (2005). Value-at-risk versus expected shortfall: A practical perspective. Link para PDF: https://scispace.com/pdf/value-at-risk-versus-expected-shortfall-a-practical-4b7n9oldxi.pdf
Karmakar, Madhusudan; Paul, Samit (2019). Intraday portfolio risk management using VaR and CVaR: A CGARCH-EVT-Copula approach. Link para PDF: https://www.sciencedirect.com/science/article/pii/S0169207018300360
Nadarajah, Saralees; Zhang, Bo; Chan, Eric (2014). Estimation methods for expected shortfall. Link para PDF: https://www.tandfonline.com/doi/pdf/10.1080/14697688.2013.816767


### Parâmetros Vencedores (Ranges)

A literatura de risco e regulatória converge para o **Expected Shortfall (ES)** como medida de risco preferida, por ser uma medida coerente (subaditiva) e capturar o risco de cauda (tail risk) [1].

**Parâmetros Numéricos e Ranges Recomendados:**

| Parâmetro | Valor/Range Recomendado | Justificativa |
| :--- | :--- | :--- |
| **Medida de Risco** | Expected Shortfall (ES) / CVaR | Coerente, captura a magnitude da perda além do VaR, e é o padrão regulatório (FRTB) [1]. |
| **Nível de Confiança ($\alpha$)** | 97.5% | Padrão regulatório (Fundamental Review of the Trading Book - FRTB) para cálculo de capital. Para trading quantitativo, 95% ou 99% são comuns, mas 97.5% é um ponto de equilíbrio robusto [2]. |
| **Horizonte Temporal ($\Delta t$)** | 1 dia | Para gestão de risco diária (daily risk management) em trading. O VaR/ES de 10 dias é tipicamente usado para cálculo de capital regulatório, mas é escalado a partir do 1-dia [2]. |
| **Período de Lookback (Dados Históricos)** | Mínimo de 1 ano (250 dias úteis) | Padrão regulatório. A literatura sugere que o ES requer um período de lookback maior que o VaR para atingir a mesma precisão [1]. |
| **Modelo de Estimação** | Modelos Condicionais (e.g., GARCH, EVT-Copula) | Modelos que incorporam volatilidade variável no tempo (GARCH) e Teoria do Valor Extremo (EVT) são mais precisos para prever o risco de cauda (ES) do que a Simulação Histórica simples [2]. |

**Regras de Ouro (Rules of Thumb) para Trading Quantitativo:**

1.  **Foco na Coerência:** Utilize **CVaR/ES** em vez de VaR para otimização de portfólio, pois o CVaR é uma medida de risco coerente, garantindo que a diversificação sempre reduza o risco (propriedade de subaditividade) [1].
2.  **Ajuste para Volatilidade:** Para trading de alta frequência ou em mercados voláteis, modelos que capturam a heterocedasticidade (como **GARCH** ou **EWMA**) são cruciais para estimativas de risco mais responsivas e precisas [2].
3.  **Backtesting Rigoroso:** O backtesting do ES é mais complexo que o do VaR. A literatura recente sugere métodos não paramétricos e testes de coerência para validar a precisão do modelo [2].
4.  **Amostra Suficiente:** O ES, por focar na cauda da distribuição, é mais sensível ao tamanho da amostra. Garanta um período de lookback longo o suficiente (e.g., > 250 dias) para capturar eventos extremos relevantes [1].


### Diferenças Brasil vs EUA

A principal diferença na implementação de VaR/CVaR/ES entre os mercados desenvolvidos (EUA) e emergentes (Brasil) reside na **maturidade regulatória** e nas **características intrínsecas do mercado**.

| Característica | Mercado Desenvolvido (EUA) | Mercado Emergente (Brasil) |
| :--- | :--- | :--- |
| **Padrão Regulatório** | **Basel III Endgame (FRTB)**: Substituição do VaR pelo **Expected Shortfall (ES)** a 97.5% para cálculo de capital de risco de mercado [4] [5]. | **Basel III (FRTB)**: Implementação faseada pelo Banco Central do Brasil (BCB), com a Fase 3 (regras de SBM e RRAO) reforçando o uso do ES [6]. |
| **Liquidez e Dados** | Alta liquidez e disponibilidade de dados históricos de alta frequência. Modelos complexos (e.g., CGARCH-EVT-Copula) são implementáveis com maior precisão [2]. | **Baixa liquidez e "thin trading"** em alguns ativos. A escassez de dados de alta frequência e a falta de liquidez tornam a estimação do ES mais desafiadora e sensível ao período de lookback [7]. |
| **Distribuição de Retornos** | Retornos tendem a ser mais próximos da normalidade (embora com caudas gordas). | Retornos exibem **caudas mais gordas e assimetria** mais pronunciadas. Modelos VaR convencionais (e.g., paramétrico-normal) tendem a **subestimar o risco** de forma mais severa [8]. |
| **Implicação para Trading Quantitativo** | Foco na otimização de modelos e na precisão do backtesting do ES. | Necessidade crítica de modelos que capturem a **Teoria do Valor Extremo (EVT)** e ajustem para a **não-normalidade** e **heterocedasticidade** (e.g., modelos GARCH ou EVT-Copula) [8]. |

**Conclusão:** Embora ambos os mercados estejam convergindo para o **Expected Shortfall (ES)** como medida regulatória e de gestão de risco, a implementação no Brasil exige uma atenção maior aos desafios de **dados de baixa liquidez** e à **não-normalidade** dos retornos, o que torna a escolha do modelo de estimação (e.g., EVT-Copula) ainda mais crucial do que nos EUA.


---


## Tópico 6: Parâmetros Ótimos para Stop-Loss Baseado em ATR (Average True Range) em Trading Quantitativo.

### Fontes Principais

Vezeris, D., Kyrgos, T., & Schinas, C. (2018). Take Profit and Stop Loss Trading Strategies Comparison in Combination with an MACD Trading System. https://pdfs.semanticscholar.org/1f98/04b60040af7a8b8a077852b296502a134e4f.pdf
Aigner, A. A., & Schrabmair, W. (2020). Power Assisted Trend Following. https://papers.ssrn.com/sol3/Delivery.cfm/SSRN_ID3605206_code3726220.pdf?abstractid=3541642&mirid=1
Wilder Jr., J. W. (1978). New Concepts in Technical Trading Systems. (Conceito fundamental do ATR e 3x ATR).
TradersPost Blog. (2025). Stop Loss Strategies for Algorithmic Trading. https://blog.traderspost.io/article/stop-loss-strategies-algorithmic-trading


### Parâmetros Vencedores (Ranges)

A literatura acadêmica e a prática de mercado sugerem que os parâmetros ótimos para o stop-loss baseado em ATR (Average True Range) são altamente dependentes do ativo, do *timeframe* e da estratégia utilizada, mas convergem para um *range* de "regras de ouro" e um ponto de partida para otimização.

| Parâmetro | Range Recomendado | Regra de Ouro (Wilder) | Otimização Específica (Vezeris et al.) |
| :--- | :--- | :--- | :--- |
| **Período do ATR (N)** | 10 a 21 | 14 | 12 |
| **Multiplicador (x)** | 1.5x a 3.0x | 3.0x | 6.0x |

**Resumo e Justificativas:**

1.  **Multiplicador (x):** O valor mais citado como "regra de ouro" é **3.0x ATR** [3], conforme introduzido por J. Welles Wilder Jr., o criador do indicador. Este multiplicador visa posicionar o *stop* fora do "ruído" normal do mercado, permitindo que o *trade* se desenvolva. O *range* prático mais comum é de **1.5x a 3.0x** [4].
2.  **Otimização Extrema:** Um estudo acadêmico que testou estratégias de *stop-loss* em combinação com o MACD em diversos mercados (Forex, Metais, Energia e Criptomoedas) encontrou que o melhor resultado para uma estratégia de ATR variável e deslizante foi com um **multiplicador de 6.0x** e um **período de 12** [1]. Este resultado sugere que, em estratégias de *trend following* que buscam capturar grandes movimentos, *stops* muito mais largos podem ser necessários.
3.  **Período (N):** O período padrão é **14** (dias ou barras), mas a otimização deve ser realizada entre 10 e 21. Períodos menores (e.g., 10) tornam o *stop* mais sensível à volatilidade recente, enquanto períodos maiores (e.g., 21) o tornam mais suave.

**Parâmetros Vencedores (Síntese):** O ponto de partida para a otimização quantitativa deve ser **N=14 e x=3.0**. Para estratégias de *trend following* de longo prazo ou em ativos de alta volatilidade (como criptomoedas ou mercados emergentes), a otimização deve explorar multiplicadores mais altos, como **x=4.0 a x=6.0**, e períodos mais curtos, como **N=12**, para encontrar o equilíbrio ideal entre proteção contra o ruído e a retenção de posições vencedoras.


### Diferenças Brasil vs EUA

A principal diferença reside na **volatilidade intrínseca** e na **liquidez** dos mercados. O mercado brasileiro (B3) é historicamente mais volátil e menos líquido em comparação com os mercados desenvolvidos (EUA - NYSE/NASDAQ), especialmente em ativos de menor capitalização.

**Implicações para o ATR Stop-Loss:**

1.  **Multiplicador (x):** A maior volatilidade e a presença de *gaps* de preço mais frequentes no Brasil (devido à menor liquidez e maior influência de fatores macroeconômicos) exigem um **multiplicador ATR maior** (x > 3) para evitar ser "stopado" prematuramente (*whipsaw*).
2.  **Período (N):** A necessidade de uma resposta mais rápida à volatilidade pode sugerir um **período ATR (N) menor** (e.g., N=10 ou N=12) para capturar a volatilidade recente de forma mais ágil.
3.  **Risco de Execução:** Nos EUA, a execução de *stop-loss* é geralmente mais precisa. No Brasil, o risco de *slippage* (derrapagem) é maior, especialmente em momentos de alta volatilidade, o que torna o ATR um método mais robusto do que *stops* fixos percentuais, mas ainda exige cautela na escolha do *broker* e tipo de ordem.

**Conclusão:** A otimização dos parâmetros (N e x) para o mercado brasileiro é **obrigatória** e deve resultar em *stops* mais largos (multiplicador maior) do que os 2x-3x comumente citados para os EUA, para acomodar a maior amplitude de movimento diário (True Range).


---


## Tópico 7: Impacto de Circuit Breakers (Paralisadores de Circuito) em Estratégias de Trading Intraday, com foco em parâmetros numéricos e comparação entre os mercados dos EUA e Brasil.

### Fontes Principais

Autor (Ano). Título. Link para PDF.
Lin, K., Gurrola-Pérez, P., & Speth, B. (2022). Circuit breakers and market quality. https://wfe-live.lon1.cdn.digitaloceanspaces.com/org_focus/storage/media/US_Circuit_Breakers_V20220914%20w_Cover2.pdf
Goldstein, M. A., & Kavajecz, K. A. (2004). Trading strategies during circuit breakers and extreme market movements. N/A (Artigo pago, mas resumo e detalhes extraídos)
Smaniotto, E., et al. (2020). Circuit breakers and volatility: Evidence from high frequency data on brazilian stock exchange. N/A (Link direto falhou, mas resumo e detalhes extraídos)
B3. (2020). Circuit breaker. N/A (Link para página oficial da B3: https://www.b3.com.br/en_us/news/circuit-breaker-8AE490CA70CB10030170CEECFCE05EAF.htm)


### Parâmetros Vencedores (Ranges)

A literatura acadêmica sugere que os "parâmetros vencedores" para estratégias de trading quantitativo em torno de *circuit breakers* não se referem a valores de entrada/saída, mas sim a **parâmetros de calibração de risco e liquidez** que governam o comportamento da estratégia antes, durante e após a paralisação.

**1. Parâmetros de Liquidez e Custo de Transação (Pós-CB - EUA [1]):**
*   **Spread Bid-Ask:** A redução média observada no spread após a retomada do trading foi de **37.5 bps** (pontos-base) [1].
*   **Impacto de Preço (Kyle's Lambda):** Redução de **16.5 bps** [1].
*   **Implicação:** Estratégias quantitativas devem calibrar seus modelos de custo de transação para esperar uma **melhoria na liquidez** e **menor impacto de preço** imediatamente após a retomada do trading, em contraste com o período de alta volatilidade que precedeu o disparo.

**2. Parâmetros de Timing e Agressividade (Pré-CB - EUA [2]):**
*   **Timing:** A proximidade do disparo do *circuit breaker* (aumento da probabilidade) atua como um parâmetro de **aceleração de ordens** (o chamado *magnet effect*), onde os traders aumentam a demanda por ordens de venda imediatas e mais agressivas [2].
*   **Implicação:** Estratégias quantitativas que buscam liquidez ou que dependem de ordens limite devem incorporar um **parâmetro de risco/agressividade** que:
    *   **Aumente a agressividade** (migração de ordens limite para ordens de mercado) à medida que o preço se aproxima do limite de disparo.
    *   **Retire ordens limite** do livro para evitar serem executadas a preços desfavoráveis ou serem bloqueadas durante a paralisação.

**3. Parâmetros de Volatilidade (Pós-CB - Brasil [3]):**
*   **Volatilidade Esperada:** O mecanismo de *circuit breaker* na B3 mostrou-se eficaz em **reduzir a volatilidade esperada** no dia em que é acionado [3].
*   **Implicação:** Estratégias de *mean-reversion* ou de volatilidade devem calibrar seus modelos para uma **redução da volatilidade** após a retomada, e não para uma continuação da tendência de pânico. O parâmetro de tempo de **30 minutos** (Nível 1) e **60 minutos** (Nível 2) de paralisação deve ser incorporado como um período de **reset de volatilidade**.

**Regra de Ouro para Trading Quantitativo:**
A regra de ouro é incorporar o *circuit breaker* como um **evento de regime de mercado** com parâmetros de liquidez e volatilidade distintos. A estratégia deve ter um módulo de **gestão de ordens** que se torna mais agressivo (em termos de execução) e mais defensivo (em termos de exposição) à medida que o preço se aproxima do limite de disparo, e que se reajusta para um regime de **maior liquidez/menor volatilidade** após a retomada. O **tempo de paralisação** (15 min nos EUA, 30/60 min no Brasil) é um parâmetro crítico de *delay* a ser modelado.


### Diferenças Brasil vs EUA

**Comparação Estruturada: Circuit Breakers EUA (S&P 500) vs. Brasil (Ibovespa)**

| Característica | EUA (S&P 500) | Brasil (Ibovespa) | Implicação para Estratégias Quantitativas |
| :--- | :--- | :--- | :--- |
| **Índice de Disparo** | S&P 500 Index | Ibovespa | O S&P 500 é mais diversificado; o Ibovespa, com maior concentração, pode ser mais volátil. |
| **Nível 1 (Queda)** | 7% | 10% | Os EUA intervêm mais cedo (7%), exigindo que estratégias quantitativas no Brasil tolerem uma volatilidade intraday maior antes da primeira paralisação. |
| **Duração da Parada (Nível 1)** | 15 minutos | 30 minutos | A B3 impõe uma parada inicial mais longa, oferecendo mais tempo para reavaliação de risco e rebalanceamento de portfólio. Estratégias de arbitragem ou de alta frequência são interrompidas por um período maior no Brasil. |
| **Nível 2 (Queda)** | 13% | 15% | Limites percentuais próximos, mas o limite inicial mais baixo dos EUA significa que o Nível 2 é atingido mais rapidamente. |
| **Duração da Parada (Nível 2)** | 15 minutos | 60 minutos (1 hora) | A diferença na duração da parada do Nível 2 é significativa (15 min vs. 60 min), impactando drasticamente o tempo de inatividade do mercado e a janela de oportunidade/risco. |
| **Nível 3 (Queda)** | 20% | 20% | Nível idêntico, resultando no fechamento do mercado pelo resto do dia em ambos. |
| **Regra de Tempo (Nível 1 & 2)** | Não se aplica após 3:25 p.m. ET | Não se aplica nos últimos 30 minutos; se acionado na última hora, adia o fechamento em 30 min. | A regra da B3 é mais complexa e visa garantir a retomada, o que pode criar uma janela de oportunidade/risco no final do dia. A regra dos EUA é mais simples, focando em evitar paralisações muito próximas ao fechamento. |
| **Efeito Pós-CB (Acadêmico)** | Redução de custos de transação e estabilização de retornos [1]. | Redução da volatilidade esperada no dia [3]. | Estratégias devem ser calibradas para o comportamento de liquidez específico de cada mercado (retirada vs. estabilização). |


---


## Tópico 8: Concentração de Portfólio vs. Diversificação: Número Ótimo de Posições para Trading Quantitativo

### Fontes Principais

1. Lassance, N., Vanderveken, R., & Vrins, F. (2025). Optimal Portfolio Size under Parameter Uncertainty. Link para PDF: https://papers.ssrn.com/sol3/Delivery.cfm/4886000.pdf?abstractid=4886000
2. Kan, R., & Zhou, G. (2007). Optimal Portfolio Choice with Parameter Uncertainty. Link para PDF: https://www-2.rotman.utoronto.ca/~kan/papers/erisk8.pdf
3. Statman, M. (1987). How Many Stocks Make a Diversified Portfolio? Link para PDF: https://www.researchgate.net/profile/Meir-Statman/publication/227406059_How-Many-Stocks-Make-a-Diversified-Portfolio/links/5593111e08aed7453d4652c2/How-Many-Stocks-Make-a-Diversified-Portfolio.pdf


### Parâmetros Vencedores (Ranges)

A literatura quantitativa moderna diverge da 'regra de ouro' tradicional de 30 ativos, focando na mitigação do **risco de estimação** (estimation risk) em modelos de otimização de Média-Variância (MV).

**1. Otimização de Média-Variância (MV) e Variância Mínima (SMV) (Lassance et al., 2025):**
- **Parâmetro Chave:** O número ótimo de ativos (N*) é uma função do tamanho da amostra de dados (T, em meses ou períodos) e da correlação média (ρ) entre os ativos.
- **Range Recomendado (Regra de Dois Fundos):** O N* que maximiza a utilidade fora da amostra é aproximadamente **N* ≈ T/2**. Para uma amostra de 5 anos (T=60 meses), o N* ótimo seria em torno de **30 ativos**. Para 10 anos (T=120), seria **60 ativos**.
- **Range Recomendado (Portfólio de Variância Mínima - SMV):** O N* é tipicamente **muito pequeno**, geralmente **N* ≤ 10**, mesmo com amostras grandes (T=240), pois o SMV é extremamente sensível ao risco de estimação.
- **Justificativa:** A diversificação deve ser limitada para evitar que o erro de estimação dos parâmetros (médias e covariâncias) anule os ganhos de diversificação. O N* ideal é o *trade-off* entre acessar oportunidades e limitar o risco de estimação.

**2. Diversificação Ingênua (Statman, 1987):**
- **Range Recomendado:** **10 a 20 ativos** são suficientes para eliminar a maior parte do risco não-sistemático. **30 a 40 ativos** são necessários para um portfólio considerado 'bem diversificado' em um contexto de investidor individual (não-quantitativo).


### Diferenças Brasil vs EUA




---


## Tópico 9: Perfil de liquidez do mercado B3 (Brasil) e seu impacto no escorregamento (slippage) para High-Frequency Trading (HFT).

### Fontes Principais

Ramos, H. P., & Perlin, M. S. (2020). Does algorithmic trading harm liquidity? Evidence from Brazil. Link para PDF: https://download.bibis.ir/Books/Artificial-Intelligence/Machine-Learning/2025/Machine%20Learning%20in%20Finance%20Trends,%20Developments%20and%20Business%20Practices%20in%20the%20Financial%20Sector%20(Musa%20G%C3%BCn%20%C2%B7%20Burcu%20Kartal)_bibis.ir.pdf
Conegundes, L., & Pereira, A. C. M. (2024). A Methodology for Developing Deep Reinforcement Learning Trading Strategies: A Case Study in the Futures Market. Link para PDF: https://ieeexplore.ieee.org/abstract/document/10772851/
Da Costa, A. S., Ceretta, P. S., & Müller, F. M. (2015). Market microstructure – a high frequency analysis of volume and volatility intraday patterns across the Brazilian stock market. Link para PDF: https://periodicos.ufsm.br/reaufsm/article/view/10505/pdf


### Parâmetros Vencedores (Ranges)

**1. Impacto no Slippage (Realized Spread):**
*   **Parâmetro:** *Realized Spread* (custo de transação efetivo).
*   **Range/Valor:** O estudo de Ramos & Perlin (2020) mostrou um **aumento significativo** nos *realized spreads* para 26 ações da B3 entre 2017 e 2018 após a mudança de data center, indicando um **aumento no slippage** para ordens executadas. Embora não forneça um range prescritivo, a "regra de ouro" é que o slippage esperado na B3 é **maior** do que o observado em mercados desenvolvidos para estratégias de AT/HFT, exigindo modelos de execução mais robustos.

**2. Estrutura de Custos para Modelagem (Mercado Futuro):**
*   **Parâmetro:** Custo de Transação.
*   **Valor:** **Fixo por unidade negociada** (Conegundes & Pereira, 2024).
*   **Justificativa:** Para HFT no mercado futuro da B3 (como o Ibovespa futuro), o modelo de recompensa deve incorporar um custo fixo de transação, simplificando a modelagem de slippage em comparação com os modelos *maker-taker* dos EUA.

**3. Performance de Estratégias (Deep Reinforcement Learning - DRL):**
*   **Parâmetro:** *Probabilistic Sharpe Ratio* (PSR) e Retorno Anualizado.
*   **Range/Valor:** PSR de **0.96** e Retorno Anualizado **acima de 100%** (Conegundes & Pereira, 2024).
*   **Justificativa:** O sucesso de estratégias de DRL no mercado futuro da B3 demonstra que, apesar da microestrutura desafiadora, a volatilidade e a liquidez concentrada oferecem oportunidades significativas para sistemas adaptativos. O PSR de 0.96 é um benchmark de performance robusta.

**4. Padrões Intraday de Volatilidade e Volume:**
*   **Parâmetro:** Volatilidade e Volume Intraday.
*   **Regra de Ouro:** Ambos seguem um padrão em forma de "U" (alto no início e no final do pregão), com a **volatilidade sendo mais alta no início** e o **volume mais concentrado no final** (Da Costa et al., 2015).
*   **Justificativa:** Para minimizar o slippage, as estratégias de HFT devem concentrar a execução de ordens grandes em períodos de **alto volume e baixa volatilidade** (geralmente o meio do dia, fora dos picos de abertura e fechamento), ou usar algoritmos de *smart order routing* que otimizem a execução em torno desses picos de liquidez.


### Diferenças Brasil vs EUA

**Diferença Fundamental na Relação AT-Liquidez:**
*   **EUA (Mercados Desenvolvidos):** A literatura majoritária aponta que o Algorithmic Trading (AT) e o HFT geralmente **aumentam a liquidez** e reduzem os custos de transação (spreads).
*   **Brasil (B3 - Mercado Emergente):** Estudos como Ramos & Perlin (2020) fornecem evidências contrárias, mostrando que o AT **aumentou os *realized spreads*** (uma medida de custo de transação e, portanto, slippage) no mercado de ações da B3 após a adoção de um novo data center em 2017. Isso sugere que, em um mercado emergente como o Brasil, o HFT pode ser mais extrativo de liquidez do que provedor, resultando em maior slippage para participantes passivos.

**Diferença na Estrutura de Custos de Transação:**
*   **EUA:** As principais bolsas (e.g., NYSE, NASDAQ) operam com modelos de *maker-taker* complexos, que oferecem **rebates** para provedores de liquidez (makers) e cobram taxas de tomadores de liquidez (takers).
*   **Brasil (B3 - Mercado Futuro):** O mercado futuro da B3, amplamente utilizado por HFT, é caracterizado por **custos de transação fixos por unidade negociada** (Conegundes & Pereira, 2024). Essa estrutura simplificada é um parâmetro crucial para a modelagem de slippage e recompensa em estratégias de DRL/HFT, contrastando com a otimização de rebates necessária nos EUA.

**Diferença na Microestrutura:**
*   A B3 apresenta **padrões intraday de volume e volatilidade** que, embora sigam o formato em "U" (alto no início e fim do dia), são influenciados por uma liquidez mais concentrada e menos profunda em comparação com os mercados dos EUA, exigindo maior atenção ao *timing* de execução para mitigar o slippage (Da Costa et al., 2015).


---


## Tópico 10: Regulamentação e Custos de Short Selling (Aluguel de Ativos e Futuros de BTC) na B3.

### Fontes Principais




### Parâmetros Vencedores (Ranges)

**Parâmetros de Custo e Ranges para Short Selling de Ações (Aluguel de Ativos):**

*   **Taxa de Aluguel (Fee):** Altamente heterogênea, variando de **abaixo de 1% ao ano** (para ações líquidas e *easy-to-borrow*, como BBDC4, ITUB4) até **acima de 10% ao ano** (para ações *hard-to-borrow*, como CIEL3, RADL3) [1].
*   **Custo Fixo B3:** **0,25% ao ano** sobre o valor nocional do empréstimo, adicionado à taxa de aluguel negociada [1].
*   **Impacto de Arbitragem:** Em períodos de oportunidades de arbitragem (ex: distribuição de Juros sobre Capital Próprio - JCP), a taxa média de empréstimo pode saltar **cinco vezes** (de ~2% para **10%** do valor nocional), e o *short interest* (posição vendida) pode aumentar de **2,2% para 3%** do total de ações em circulação [2].
*   **Regra de Ouro Quantitativa:** O custo do empréstimo (*loan fee*) é um **parâmetro preditivo** crucial. Altas taxas de empréstimo indicam restrições de *short-selling* e, consequentemente, preveem **retornos negativos futuros** para a ação, devido à pressão de investidores informados [3].

**Parâmetros de Custo e Ranges para Short Selling de BTC (Contrato Futuro - BIT):**

*   **Tamanho do Contrato:** **1%** do valor de um Bitcoin.
*   **Tick Size:** **R$0,01** por ponto.
*   **Margem Day Trade (Range):** Varia entre **R$50,00 e R$100,00** por contrato, dependendo da corretora.
*   **Margem Swing Trade:** Aproximadamente **50%** do volume financeiro do contrato.
*   **Custo de Negociação (Day Trade):** Taxa de corretagem e emolumentos da B3 (ex: corretagem em torno de **R$0,72** por contrato, após reduções).

**Regra de Ouro Quantitativa (Geral):** A **conectividade** do *short-seller* com os corretores e doadores é um parâmetro "vencedor" no mercado brasileiro, pois *short-sellers* bem conectados pagam **taxas de aluguel significativamente mais baixas** para o mesmo ativo no mesmo dia, reduzindo o custo de execução da estratégia [3].


### Diferenças Brasil vs EUA




---


## Tópico 11: Pesquisa acadêmica sobre a microestrutura do mercado de ações dos EUA e o impacto da Regulation NMS (Reg NMS) na execução de ordens, com foco em parâmetros numéricos para trading quantitativo e comparação com o mercado brasileiro (B3).

### Fontes Principais

Autor (Ano). Título. Link para PDF.
1. Almgren, R. & Chriss, N. (2000). Optimal Execution of Portfolio Transactions. https://www.smallake.kr/wp-content/uploads/2016/03/optliq.pdf
2. Cont, R. & Kukanov, A. (2012). Optimal order placement in limit order markets. https://arxiv.org/pdf/1210.1625
3. Chung, K. H., & Chuwonganant, C. (2012). Regulation NMS and Market Quality. https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1755-053X.2012.01184.x
4. Easley, D., O'Hara, M., & Yang, L. (2016). Optimal Execution Horizon. https://easley.economics.cornell.edu/docs/Optimal%20Execution%20Horizon.pdf


### Parâmetros Vencedores (Ranges)

O resumo dos "parâmetros vencedores" na literatura de execução ótima (principalmente no framework Almgren-Chriss) não se refere a valores fixos, mas sim a **funções de custo e risco** que determinam a **trajetória de negociação ótima**.

**Parâmetros Chave e Ranges Recomendados:**

1.  **Horizonte de Execução ($T$):**
    *   **Função:** O tempo total permitido para liquidar o volume total de ações ($X$).
    *   **Recomendação:** Deve ser escolhido para equilibrar o custo de impacto de mercado (favorece $T$ longo) e o risco de preço (favorece $T$ curto). A escolha ótima é uma função do volume total ($X$), da volatilidade ($\sigma$), e da aversão ao risco ($\lambda$).

2.  **Aversão ao Risco ($\lambda$):**
    *   **Função:** Ponderação do *trader* entre custo esperado e variância do custo (risco).
    *   **Range:** $\lambda \ge 0$. Valores mais altos (e.g., $\lambda \approx 10^{-6}$ a $10^{-7}$ para grandes fundos) indicam maior aversão ao risco.
    *   **Justificativa:** Determina a forma da curva de execução. Um $\lambda$ alto resulta em uma execução mais lenta e suave para minimizar o risco, enquanto $\lambda=0$ (neutro ao risco) resulta em execução mais rápida.

3.  **Impacto de Mercado Temporário ($\eta$):**
    *   **Função:** Custo que se dissipa após a negociação (custo de liquidez).
    *   **Recomendação:** Otimização busca uma taxa de negociação $v(t)$ que minimize $\int \eta v(t)^2 dt$. O parâmetro $\eta$ é calibrado empiricamente e varia por ativo e liquidez.

4.  **Impacto de Mercado Permanente ($\gamma$):**
    *   **Função:** Deslocamento permanente do preço após a negociação.
    *   **Recomendação:** Otimização busca minimizar o volume total negociado em ordens de mercado, favorecendo ordens limite.

5.  **Tamanho Ótimo da Ordem (Order Slice Size):**
    *   **Regra de Ouro:** Evitar que a ordem exceda uma fração do volume médio negociado (e.g., **< 5-10% do Volume Médio Diário (ADV)**) ou **< 10-20% do volume do *order book* no *top-of-book***.
    *   **Justificativa:** Minimiza o impacto de mercado e o risco de *information leakage*. Cont & Kukanov (2012) mostram que o tamanho ótimo é uma função da profundidade da fila e do fluxo de ordens.

**Impacto da Reg NMS na Execução:** A Reg NMS aumentou a complexidade do roteamento de ordens (*Smart Order Routers* - SORs). O parâmetro crítico aqui é a **latência** (tempo de resposta do SOR) e a **capacidade de roteamento** para capturar o melhor preço em um mercado fragmentado. O custo de execução é uma função não linear da latência e da probabilidade de execução em diferentes *venues*.


### Diferenças Brasil vs EUA

**Comparação Estrutural: Microestrutura de Mercado EUA (Reg NMS) vs. Brasil (B3)**

| Característica | Mercado Americano (EUA) - Reg NMS | Mercado Brasileiro (Brasil) - B3 |
| :--- | :--- | :--- |
| **Estrutura de Mercado** | **Fragmentada** (Múltiplas bolsas, ECNs, *dark pools*). A Reg NMS exige roteamento para o melhor preço (NBBO). | **Centralizada** (B3 como bolsa única e verticalmente integrada). Embora a CVM tenha introduzido regras de melhor execução, a centralização é a característica dominante. |
| **Regra de Melhor Execução** | **Order Protection Rule (OPR)**: Proíbe *trade-throughs* (negociar a um preço pior que o NBBO). O dever de melhor execução é implícito e altamente regulamentado. | **Dever de Melhor Execução (CVM)**: Recai sobre o intermediário (corretora), exigindo que provem ter obtido o melhor resultado para o cliente, especialmente em cenários de múltiplas plataformas (embora a B3 seja a principal). |
| **Custódia e Liquidação** | **Descentralizada** (Múltiplos custodiantes e câmaras de compensação). | **Centralizada** (B3 realiza a custódia e liquidação para a maioria dos ativos). |
| **Tick Size (Tamanho Mínimo do Preço)** | **$0.01 USD** para a maioria das ações (exceto para as de menor preço, que podem ter *tick sizes* maiores ou menores sob novas regras). | **Variável** por ativo e faixa de preço. A B3 define tabelas de *tick size* que variam de R$ 0,01 a R$ 0,0001, dependendo do preço da ação e do tipo de contrato. |
| **Impacto para Trading Quantitativo** | **Complexidade de Roteamento (SORs)**: O foco é na otimização do roteamento entre *venues* para capturar *rebates* e evitar *trade-throughs*. A latência é crítica. | **Foco em Liquidez e Profundidade**: O foco é mais na gestão do impacto de mercado em um *order book* único e na latência para a B3. A menor liquidez em alguns ativos exige maior atenção ao *market impact*. |


---


## Tópico 12: Pesquisa acadêmica e regulatória sobre as regras da FINRA e SEC para trading algorítmico e acesso ao mercado (Rule 15c3-5).

### Fontes Principais

1. Chakrabarty, B., Jain, P. K., Shkilko, A., & Sokolov, K. (2021). Unfiltered market access and liquidity: evidence from the SEC Rule 15c3-5. Management Science, 67(2), 1183-1198. Link para PDF: https://pubsonline.informs.org/doi/pdf/10.1287/mnsc.2019.3466
2. U.S. Securities and Exchange Commission (SEC). (2010). Final Rule: Risk Management Controls for Brokers or Dealers With Market Access (Release No. 34-63241). Link para PDF: https://www.sec.gov/files/rules/final/2010/34-63241.pdf
3. FINRA. (2015). Regulatory Notice 15-09: Guidance on Effective Supervision and Control Practices for Firms Engaging in Algorithmic Trading Strategies. Link para PDF: https://www.finra.org/rules-guidance/notices/15-09
4. U.S. Securities and Exchange Commission (SEC). (2014). Trading & Markets Frequently Asked Questions (FAQ on Rule 15c3-5). Link para PDF: https://www.sec.gov/rules-regulations/staff-guidance/trading-markets-frequently-asked-questions/divisionsmarketregfaq-0


### Parâmetros Vencedores (Ranges)

A Rule 15c3-5 não estabelece valores numéricos fixos, mas sim a obrigação de implementar controles de risco pré-negociação que sejam **"razoavelmente projetados"** (*reasonably designed*) para o modelo de negócio da corretora. A "regra de ouro" é a **personalização** e a **sistematicidade** dos controles.

**Parâmetros e Recomendações Chave:**

*   **Limites de Crédito/Capital:** O sistema deve rejeitar ordens que excedam limites **apropriados e pré-definidos** (SEC Rule 15c3-5(c)(1)(i)). Devem ser estabelecidos de forma **sistemática** para cada cliente e para a corretora, e refinados por setor ou título, visando prevenir perdas financeiras catastróficas.
*   **Limites de Preço (Price Parameters):** O sistema deve rejeitar ordens que excedam um preço razoável (ex: um percentual de desvio do preço de mercado atual). O objetivo é prevenir a entrada de **ordens errôneas** (*erroneous orders*) (SEC Rule 15c3-5(c)(1)(ii)).
*   **Limites de Tamanho (Size Parameters):** O sistema deve rejeitar ordens que excedam um tamanho razoável (ex: um percentual do volume médio diário). O objetivo é evitar que uma única ordem cause impacto indevido no mercado (SEC Rule 15c3-5(c)(1)(ii)).
*   **Revisão Periódica:** O CEO (ou equivalente) deve **certificar anualmente** que os controles são eficazes e estão em conformidade (SEC Rule 15c3-5(e)).

**Resumo:** Os "parâmetros vencedores" são a **implementação robusta e personalizada** de controles de **preço, tamanho e capital** que são revisados anualmente e que são **direta e exclusivamente controlados** pela corretora que fornece o acesso ao mercado.


### Diferenças Brasil vs EUA

**Comparação Estrutural da Regulamentação de Trading Algorítmico (Rule 15c3-5 vs. Brasil)**

| Característica | Mercado Desenvolvido (EUA - SEC Rule 15c3-5) | Mercado Emergente (Brasil - CVM/B3) |
| :--- | :--- | :--- |
| **Base Legal Primária** | **Regra Federal Específica (Rule 15c3-5)** da SEC. | **Estrutura de Auto-Regulamentação e Normativos** (CVM e B3). |
| **Natureza da Regra** | **Baseada em Princípios**, exigindo que os controles sejam "razoavelmente projetados" e personalizados. | **Mista (Princípios e Regras Explícitas)**, com forte dependência de normativos operacionais da B3. |
| **Responsabilidade Primária** | **Corretora (Market Access Provider)**. A regra impõe a responsabilidade primária e o controle exclusivo dos sistemas de risco à corretora. | **Compartilhada (B3 e Corretoras)**. A B3 opera controles centrais (LiNe, Túneis de Negociação), e as corretoras devem complementar e gerenciar seus clientes. |
| **Controles de Risco** | Detalhados em termos de **crédito/capital, preço e tamanho** (SEC Rule 15c3-5(c)(1)). | Implementados via sistema **LiNe (Limit and Exposure)** da B3 e **Túneis de Negociação** (controles de preço e volume mais explícitos e centralizados). |
| **Certificação de Conformidade** | **Obrigatória e Anual** pelo CEO da corretora (SEC Rule 15c3-5(e)). | Não há exigência federal de certificação anual do CEO específica para o Market Access, mas sim revisões internas de compliance. |
| **Conclusão** | Foco na **responsabilidade individualizada** da corretora e na **personalização** dos controles. | Foco em **controles centrais** da bolsa (B3) para garantir a estabilidade do mercado, com a corretora atuando como um segundo nível de defesa.


---


## Tópico 13: Otimização Walk-Forward versus Validação Out-of-Sample no Desenvolvimento de Estratégias de Trading Quantitativo.

### Fontes Principais

Kaastra, I., & Boyd, M. (1996). Designing a neural network for forecasting financial and economic time series. Link para PDF: https://mediatum.ub.tum.de/doc/1734793/document.pdf
Żbikowski, K. (2015). Using volume weighted support vector machines with walk forward testing and feature selection for the purpose of creating stock trading strategy. Link para PDF: http://arc.hhs.se/download.aspx?MediumId=3944
Hu, M. Y., Zhang, G., Jiang, C. X., & Patuwo, B. E. (1999). A cross-validation analysis of neural network out-of-sample performance in exchange rate forecasting. Link para PDF: https://www.academia.edu/download/108767140/j.1540-5915.1999.tb01606.x20231211-1-qcmgvm.pdf


### Parâmetros Vencedores (Ranges)

A literatura sobre otimização *walk-forward* (WF) e validação *out-of-sample* (OOS) não define um conjunto único de "parâmetros vencedores", mas sim **regras de ouro** (rules of thumb) para as proporções de dados e a frequência de reotimização, visando mitigar o *overfitting* e o *look-ahead bias*.

| Parâmetro | Range Recomendado (Regra de Ouro) | Justificativa |
| :--- | :--- | :--- |
| **Proporção In-Sample (IS) / Out-of-Sample (OOS)** | **IS: 70% a 80%** do total de dados para otimização. **OOS: 20% a 30%** para validação. | O período IS deve ser longo o suficiente para capturar diversos ciclos de mercado e permitir uma otimização estatisticamente robusta. O período OOS deve ser significativo para testar a generalização da estratégia em dados não vistos. |
| **Comprimento da Janela de Otimização (IS)** | **Mínimo de 3 a 5 anos** de dados diários ou um número de *trades* que garanta **pelo menos 100 *trades*** por otimização. | A janela deve ser longa o suficiente para que os parâmetros ótimos encontrados não sejam específicos de um único regime de mercado. A regra de 100 *trades* por otimização é uma métrica de robustez estatística para evitar a otimização de ruído. |
| **Comprimento do Passo (Step Size) / Período OOS** | **OOS: 1/4 a 1/3 do período IS** (em termos de tempo ou número de *trades*). Mínimo de **20 a 40 *trades*** por passo. | O passo (*step size*) define a frequência de reotimização. Um passo muito curto aumenta o custo computacional e o risco de otimizar o ruído recente. Um passo muito longo pode fazer com que a estratégia falhe ao se adaptar a novos regimes de mercado. A proporção de 1/4 a 1/3 é um equilíbrio comum. |
| **Número de *Walk-Forward Runs*** | **Mínimo de 10 a 20 *runs*** (janelas de otimização/validação). | Um número maior de *runs* aumenta a confiança estatística na estabilidade dos parâmetros ótimos ao longo do tempo. O resultado final da estratégia é a concatenação dos resultados OOS de cada *run*. |

**Conclusão sobre Parâmetros:**
A literatura enfatiza que a **estabilidade dos parâmetros** (a variação dos parâmetros ótimos entre as janelas IS) é um indicador mais importante de robustez do que o desempenho absoluto no *backtest* IS. Estratégias com parâmetros ótimos que mudam drasticamente a cada reotimização são consideradas frágeis e propensas a falhar no futuro. O *walk-forward* é a ferramenta primária para medir essa estabilidade.


### Diferenças Brasil vs EUA

A principal diferença reside na **microestrutura do mercado** e na **disponibilidade/qualidade dos dados**.

| Característica | Mercados Desenvolvidos (EUA - NYSE/NASDAQ) | Mercados Emergentes (Brasil - B3) |
| :--- | :--- | :--- |
| **Liquidez e Volume** | Alta liquidez e volume, permitindo estratégias de alta frequência e execução de grandes ordens com menor impacto. | Liquidez e volume concentrados em poucos ativos (ex: Ibovespa Futuro), o que pode limitar a escalabilidade de estratégias e aumentar o *slippage*. |
| **Microestrutura** | Altamente desenvolvida, com latência ultrabaixa e alta competição. A otimização *walk-forward* deve considerar o impacto de custos de transação e latência de forma rigorosa. | Menos desenvolvida e mais volátil. A otimização *walk-forward* deve ser mais conservadora, com janelas de reotimização mais longas para absorver a maior volatilidade e menor eficiência. |
| **Disponibilidade de Dados** | Dados históricos de alta qualidade, limpos e de microestrutura (tick-by-tick) amplamente disponíveis e acessíveis por longos períodos. | Dados históricos de microestrutura podem ser mais difíceis de obter, mais caros e exigir maior esforço de limpeza devido a eventos como *splits*, *inplit* e mudanças regulatórias. |
| **Overfitting** | O risco de *overfitting* é alto devido à grande quantidade de dados e à complexidade das estratégias. O *walk-forward* é crucial para mitigar isso. | O risco de *overfitting* também é alto, mas agravado pela menor profundidade histórica e pela maior probabilidade de mudanças estruturais no mercado, exigindo validação mais robusta contra a mudança de regime. |
| **Relevância da Pesquisa** | A maior parte da literatura acadêmica (incluindo as fontes citadas) é baseada em dados de mercados desenvolvidos (EUA/Europa), tornando seus parâmetros e conclusões mais diretamente aplicáveis. | A aplicação direta dos parâmetros da literatura deve ser feita com cautela. Estudos brasileiros (ex: Campolina, 2022; Conegundes & Pereira, 2024) frequentemente utilizam o *walk-forward* para validar modelos de *Machine Learning* na B3, adaptando a metodologia à realidade local. |

Em resumo, a otimização *walk-forward* no Brasil exige maior atenção à **limitação de dados de microestrutura**, à **baixa liquidez** fora dos principais ativos e à **volatilidade** inerente a um mercado emergente, o que pode levar a janelas de otimização e validação mais longas em termos de tempo, mas potencialmente mais curtas em termos de número de *trades* devido à menor frequência de negociação em muitos ativos.


---


## Tópico 14: Algoritmos de detecção de regime de mercado para estratégias de trading adaptativas.

### Fontes Principais

Horvath, B. and Issa, Z. (2023). Non-parametric online market regime detection and regime clustering for multidimensional and path-dependent data structures. Link: https://papers.ssrn.com/sol3/Delivery.cfm/SSRN_ID4501097_code3939895.pdf?abstractid=4493344&mirid=1
Akioyamen, P., Tang, Y. Z., and Hussien, H. (2020). A Hybrid Learning Approach to Detecting Regime Switches in Financial Markets. Link: https://arxiv.org/pdf/2108.05801
Ozer, F. and Sakar, C. O. (2022). An automated cryptocurrency trading system based on the detection of unusual price movements with a Time-Series Clustering-Based approach. Link: https://www.sciencedirect.com/science/article/pii/S0957417422004353


### Parâmetros Vencedores (Ranges)

A literatura acadêmica sugere que os **parâmetros vencedores** para a detecção de regime variam conforme a metodologia e o mercado alvo. O trabalho de Akioyamen et al. (2020) sobre o mercado dos EUA, que utiliza uma abordagem híbrida de PCA e K-means, recomenda um **número de regimes (k) igual a 2**, determinado pelo método da largura média da silhueta (variando k de 1 a 6). Para a redução de dimensionalidade, o estudo utilizou **26 Componentes Principais (PCA)**, que coletivamente explicam 90% da variância dos dados econômicos originais. O período de treinamento (janela de lookback) utilizado foi de 1994 a 2013. A justificativa para k=2 é a maximização da estabilidade dos clusters, com os regimes detectados coincidindo com períodos históricos de turbulência (bolha dot-com e crise de 2008). Em contraste, Horvath e Issa (2023) propõem um método **não-paramétrico e online** baseado em Rough Path Signatures, onde o parâmetro-chave é o **tamanho da janela de dados de entrada**, que deve ser pequena para garantir maior reatividade na detecção de mudanças de regime em tempo real. Por fim, Ozer e Sakar (2022), focados no mercado de criptomoedas, utilizam um sistema adaptativo baseado em Time-Series Clustering, onde os parâmetros críticos são o **limiar de detecção de movimento incomum** (dependente da volatilidade do ativo) e a **janela de tempo** para detecção de anomalias, visando gerar sinais de trading em regimes de *outliers*.


### Diferenças Brasil vs EUA

As diferenças de implementação entre mercados desenvolvidos (EUA) e emergentes (Brasil) são estruturais e impactam diretamente a modelagem de regimes:

| Característica | Mercados Desenvolvidos (EUA) | Mercados Emergentes (Brasil) |
| :--- | :--- | :--- |
| **Disponibilidade de Dados** | Alta disponibilidade de dados históricos de alta frequência, padronização e infraestrutura robusta. | Qualidade, granularidade e profundidade histórica dos dados podem ser menores ou mais custosas, exigindo maior tratamento. |
| **Regulamentação (HFT)** | Alto grau de anonimato nas negociações de alta frequência (HFT). | A regulamentação da B3 permite a **identificação da origem final da negociação**, impactando a dinâmica de liquidez e as estratégias de HFT. |
| **Regimes de Mercado** | Regimes mais influenciados por ciclos econômicos globais e políticas monetárias de grandes bancos centrais. | Mais suscetíveis a **"choques de incerteza"** e a fatores macroeconômicos e políticos locais, resultando em regimes mais voláteis e com transições mais abruptas. |
| **Infraestrutura/Latência** | Infraestrutura de baixa latência altamente desenvolvida, essencial para detecção de regime em tempo real (online). | Desafios de infraestrutura e latência que podem limitar a eficácia de estratégias de altíssima frequência e exigir janelas de lookback mais longas. |


---


## Tópico 15: Métodos para detecção e prevenção de overfitting em backtests (e.g., Deflated Sharpe Ratio). O foco é em parâmetros numéricos e regras de ouro para trading quantitativo.

### Fontes Principais

Bailey, D. H., & López de Prado, M. (2014). The deflated Sharpe ratio: Correcting for selection bias, backtest overfitting and non-normality. Link para PDF: https://www.davidhbailey.com/dhbpapers/deflated-sharpe.pdf
Bailey, D. H., Borwein, J. M., & López de Prado, M. (2015). The probability of backtest overfitting. Link para PDF: https://www.davidhbailey.com/dhbpapers/backtest-prob.pdf
López de Prado, M. (2018). Advances in Financial Machine Learning. Link para PDF: N/A (Livro, mas o conteúdo é central para o tema)


### Parâmetros Vencedores (Ranges)

**Resumo dos Parâmetros Vencedores e Ranges Recomendados**

A literatura acadêmica, liderada pelos trabalhos sobre o **Deflated Sharpe Ratio (DSR)** e a **Probabilidade de Overfitting no Backtest (PBO)**, foca em ajustar as métricas de desempenho para o número de testes realizados ($N$) e a não-normalidade dos retornos.

| Parâmetro | Valor/Range Recomendado | Justificativa |
| :--- | :--- | :--- |
| **Nível de Significância ($\alpha$)** | **0.05 (5%)** | Valor padrão para a taxa de Falso Positivo (Erro Tipo I). Usado para calcular o DSR e o limiar de significância estatística. |
| **Sharpe Ratio de Referência ($SR^*$)** | **0** (mínimo) ou **1.0** (para estratégias de *hedge funds*) | O DSR determina a probabilidade de o SR verdadeiro ser maior que este valor de referência. |
| **Comprimento Mínimo do Histórico (T)** | **100 a 200 trades** (regra de ouro prática) | Garante que a amostra de dados seja grande o suficiente para que as estatísticas de desempenho sejam minimamente confiáveis para inferência estatística. |
| **Divisão Out-of-Sample (OOS)** | **30% a 50%** do total de dados | O desempenho OOS deve ser consistente com o *In-Sample* (IS). Uma queda significativa no OOS indica *overfitting*. |
| **DSR (Deflated Sharpe Ratio)** | **DSR > 0** e estatisticamente significativo | O DSR é o SR ajustado para o número de testes e a não-normalidade. Um DSR positivo e significativo indica que a probabilidade de a estratégia ser um Falso Positivo é menor que $\alpha$. |


### Diferenças Brasil vs EUA

**Comparação Estruturada: EUA (Desenvolvido) vs. Brasil (Emergente)**

| Característica | Mercado Desenvolvido (EUA - NYSE/NASDAQ) | Mercado Emergente (Brasil - B3) | Implicação para Backtesting e Overfitting |
| :--- | :--- | :--- | :--- |
| **Disponibilidade de Dados** | Alta disponibilidade de dados históricos de alta frequência, limpos e padronizados. | Disponibilidade mais limitada, especialmente para dados de alta frequência e séries longas. Maior incidência de *survivorship bias*. | **Risco de Overfitting:** O menor volume de dados históricos e o *survivorship bias* aumentam o risco de *overfitting*. Exige *walk-forward analysis* e *cross-validation* mais rigorosos. |
| **Liquidez e Custo de Transação** | Alta liquidez na maioria dos ativos. Custos de transação (corretagem, *slippage*) baixos e previsíveis. | Liquidez concentrada. Custos de transação (especialmente *slippage* em ativos menos líquidos) mais altos e voláteis. | **Parâmetros Vencedores:** A estratégia deve incorporar custos de transação realistas e variáveis. O Sharpe Ratio de referência ($SR^*$) deve ser mais alto para compensar os custos e o risco. |
| **Volatilidade e Não-Normalidade** | Volatilidade moderada. Retornos tendem a se aproximar da normalidade. | Alta volatilidade. Retornos com maior assimetria (*skewness*) e curtose (*kurtosis*). | **DSR:** A correção para **Não-Normalidade** (parte integrante do DSR) é ainda mais crítica no mercado brasileiro, tornando o DSR essencial para evitar ser enganado por retornos não-normais. |
| **Conclusão** | As técnicas de prevenção de *overfitting* são aplicadas com foco na correção do *selection bias* (viés de seleção) devido ao grande número de testes. | As técnicas são aplicadas com foco na correção do *selection bias* e, principalmente, na **correção da não-normalidade** e na **inclusão de custos de transação realistas** devido à escassez de dados de alta qualidade e à alta volatilidade. |


---


## Tópico 16: Pesquisa acadêmica aprofundada sobre a Análise de Custo de Transação (*Transaction Cost Analysis - TCA*) e a modelagem realista de *slippage* (*realistic slippage modeling*) em *backtests* de estratégias de *quantitative trading*. O foco é na identificação de parâmetros numéricos, *ranges* recomendados e diferenças de implementação entre mercados desenvolvidos (EUA) e emergentes (Brasil).

### Fontes Principais

1. Kissell, R., Glantz, M., & Malamut, R. (2004). A practical framework for estimating transaction costs and developing optimal trading strategies to achieve best execution. *Finance Research Letters*, 1(1), 35-46. [Link para PDF](https://isiarticles.com/bundles/Article/pre/pdf/19891.pdf)
2. Gârleanu, N., & Pedersen, L. H. (2013). Dynamic trading with predictable returns and transaction costs. *The Journal of Finance*, 68(6), 2309-2340. [Link para PDF](https://nbgarleanu.github.io/DynTrad.pdf)
3. Obizhaeva, A. A., & Wang, J. (2013). Optimal trading strategy and supply/demand dynamics. *Journal of Financial Markets*, 16(1), 1-32. [Link para PDF](http://web.mit.edu/wangj/www/pap/ObizhaevaWang13.pdf)
4. Bohn, S. (2011). The slippage paradox. *arXiv preprint arXiv:1103.2214*. [Link para PDF](https://arxiv.org/pdf/1103.2214)


### Parâmetros Vencedores (Ranges)

A literatura acadêmica sobre TCA e *slippage* em *backtests* não fornece um conjunto único de "parâmetros vencedores" fixos, mas sim **modelos e *ranges* recomendados** para os componentes de custo, que devem ser calibrados para o ativo e a estratégia específicos.

| Parâmetro | Range/Valor Recomendado | Justificativa e Contexto |
| :--- | :--- | :--- |
| **Custo Total de Transação (TCA)** | **30 a 75 *basis points* (bp)** em média, podendo exceder **200-300 bp** para ordens grandes e ilíquidas [1]. | Este é o *range* empírico de custo total (explícito + implícito) que as estratégias devem absorver. Um *backtest* que ignora custos nesse *range* é irrealista. |
| **Modelo de Impacto de Mercado (Slippage)** | **Função Quadrática** do tamanho da ordem (Modelo Almgren-Chriss) [2]. | O custo de impacto de mercado (*slippage*) é frequentemente modelado como $\text{Custo} \propto \text{Tamanho da Ordem}^2$. Isso penaliza ordens grandes e incentiva a divisão da ordem (*slicing*). |
| **Fator de Custo Temporário ($\eta$)** | Calibrado empiricamente, mas deve ser **maior para ativos ilíquidos** e **menor para ativos líquidos**. | No modelo Almgren-Chriss, $\eta$ representa o custo temporário (impacto imediato) por unidade de volume. Um *backtest* deve usar um $\eta$ que reflita a liquidez do ativo. |
| **Fator de Custo Permanente ($\gamma$)** | Calibrado empiricamente, mas deve ser **próximo de zero** para a maioria dos ativos líquidos. | $\gamma$ representa o impacto permanente no preço. Estratégias de alta frequência em ativos líquidos podem ignorar $\gamma$, mas estratégias de longo prazo ou com grande volume devem considerá-lo [2]. |
| **Resiliência de Mercado ($\tau$)** | **Meia-vida de recuperação** (*half-life*) do livro de ofertas: **0.90 a 27.03 minutos** (para o exemplo de Obizhaeva e Wang) [3]. | A resiliência é crítica. O *backtest* deve modelar a recuperação da liquidez. Quanto **maior a meia-vida ($\tau$)**, maior o custo de execução e mais lenta deve ser a estratégia ótima. |
| **Velocidade de Negociação Ótima** | **Proporcional à persistência do sinal** (*alpha decay*) [2]. | O princípio de Gârleanu e Pedersen sugere que se deve negociar **mais agressivamente** em sinais com *alpha decay* **lento** (mais persistentes) e **menos agressivamente** em sinais com *alpha decay* **rápido** (menos persistentes) para otimizar o *trade-off* entre retorno e custo de transação. |

**Regras de Ouro para Backtesting Realista:**

1.  **Não assumir o preço de fechamento (Close Price):** O *slippage* é a diferença entre o preço esperado e o preço executado. O *backtest* deve usar dados de alta frequência (tick-by-tick ou LOB) ou um modelo de *slippage* probabilístico [4].
2.  **Modelar o Custo Total:** O TCA deve incluir custos explícitos (comissões, taxas) e implícitos (impacto de mercado, *slippage* e custo de oportunidade) [1].
3.  **Calibrar a Resiliência:** A resiliência do mercado é um fator dinâmico crucial. O *backtest* deve incorporar a velocidade com que a liquidez se recupera após uma negociação, especialmente para ativos de baixa liquidez [3].
4.  **Ajustar a Velocidade:** A velocidade de execução deve ser uma variável otimizada, não fixa, e deve ser inversamente relacionada ao custo de transação e diretamente relacionada à persistência do sinal de *alpha* [2].


### Diferenças Brasil vs EUA

A principal diferença na implementação de TCA e modelagem de *slippage* entre mercados desenvolvidos (EUA) e emergentes (Brasil) reside na **microestrutura de mercado** e na **liquidez**.

1.  **Liquidez e Profundidade de Mercado:**
    *   **EUA (NYSE, NASDAQ):** Mercados de alta liquidez e profundidade. A modelagem de *slippage* e *market impact* (impacto de mercado) é frequentemente baseada em modelos como **Almgren-Chriss** (custo quadrático) ou modelos de impacto permanente/temporário, onde o impacto é relativamente previsível para a maioria dos ativos. A alta frequência de negociação e a granularidade dos dados (tick-by-tick) permitem modelos sofisticados.
    *   **Brasil (B3):** O mercado é significativamente menor e menos líquido, com um valor de mercado acionário muito inferior ao dos EUA [11]. A liquidez é mais concentrada em poucos ativos (*blue chips*). Isso implica que o *market impact* de grandes ordens é **desproporcionalmente maior** e **menos previsível** do que nos EUA. A modelagem de *slippage* deve incorporar uma **volatilidade de liquidez** mais alta e considerar o impacto de ordens grandes de forma mais agressiva.

2.  **Custos de Transação (TCA):**
    *   **EUA:** O foco do TCA é predominantemente nos custos **implícitos** (impacto de mercado e *slippage*), já que as comissões e taxas são tipicamente muito baixas ou zero para o varejo e baixíssimas para institucionais.
    *   **Brasil:** Embora as comissões tenham diminuído, as **taxas de custódia e emolumentos** da B3, embora percentualmente pequenas, podem ter um peso maior no custo total de transação para estratégias de alta frequência ou alto volume, especialmente em comparação com os custos quase nulos de corretagem nos EUA. Além disso, a B3 possui uma estrutura de taxas que diferencia entre transações *day trade* e *swing trade* [9], o que deve ser explicitamente modelado no *backtest*.

3.  **Microestrutura e Resiliência:**
    *   **EUA:** A resiliência do livro de ofertas (velocidade com que a liquidez se recupera após um *trade*) é alta para a maioria dos ativos. Modelos como o de **Obizhaeva e Wang** [3] enfatizam a importância da resiliência, que é um fator chave em mercados eficientes.
    *   **Brasil:** A menor resiliência em ativos de menor liquidez significa que o *slippage* e o impacto de mercado podem **persistir por mais tempo**, exigindo que os modelos de *backtest* usem um fator de decaimento de impacto mais lento ou considerem a execução de ordens em janelas de tempo mais longas para evitar custos excessivos.

**Conclusão:** A modelagem de *slippage* e TCA no Brasil exige uma **abordagem mais conservadora** em relação ao *market impact* e uma **atenção maior aos custos explícitos** e à **volatilidade da liquidez** do que a abordagem padrão aplicada a mercados de alta liquidez como o dos EUA.


---
