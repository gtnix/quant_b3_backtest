# Performance Analysis of OBFS Persistence Layer (LMDB/Heed)

This report analyzes the performance characteristics of the Optimized Binary File System (OBFS) persistence layer, which utilizes LMDB (via the `heed` crate) for metadata storage and a custom file system for large artifact data. The analysis focuses on configuration tuning, write batching, serialization efficiency, and potential alternative storage backends to achieve the target of a 1000x performance improvement for strategy generation.

## Key Findings

The current implementation of `MetadataStore` in the `obfs` crate exhibits several areas for significant performance optimization, primarily related to transaction management and data serialization.

*   **Synchronous Single-Operation Transactions:** Every metadata write operation (`put`, `delete`) in `MetadataStore` is wrapped in its own `write_txn` and immediately committed (`/home/ubuntu/quant_b3_backtest/crates/obfs/src/store/mod.rs:54`, `/home/ubuntu/quant_b3_backtest/crates/obfs/src/store/mod.rs:66`). This forces a disk sync for every single metadata record, leading to extremely high write latency under bulk-write scenarios, which are common during strategy generation.
*   **JSON Serialization for Metadata:** The `ArtifactMetadata` and `ArtifactLocation` structs are serialized and deserialized using `serde_json` for storage in LMDB (`/home/ubuntu/quant_b3_backtest/crates/obfs/src/store/mod.rs:57-58`, `/home/ubuntu/quant_b3_backtest/crates/obfs/src/store/mod.rs:77`). While convenient, JSON is a text-based format that introduces unnecessary overhead in both size and CPU time compared to binary serialization formats.
*   **Hardcoded LMDB Map Size:** The LMDB environment's maximum size (`map_size`) is hardcoded to 10 GB (`/home/ubuntu/quant_b3_backtest/crates/obfs/src/store/mod.rs:31`). This value is not exposed via `ObfsConfig`, making it non-tunable for different deployment environments or datasets. For a 1000x increase in strategy generation, the metadata volume will likely exceed this limit, leading to runtime errors.
*   **Conservative Default Compression Level:** The default Zstd compression level for artifacts is set to 3 (`/home/ubuntu/quant_b3_backtest/crates/obfs/src/lib.rs:74`). While fast, this is a conservative choice that may sacrifice significant storage and I/O bandwidth savings compared to higher levels, especially the already-defined `UltraCompressor` (level 19).
*   **Hybrid Persistence Model:** The architecture correctly separates metadata (LMDB) from large artifact data (custom files referenced by `ArtifactLocation` in `/home/ubuntu/quant_b3_backtest/crates/obfs/src/types.rs`). This hybrid approach is fundamentally sound for high-performance backtesting systems.

## Optimization Opportunities

1.  **Implement Bulk Write Batching for Metadata**
    *   **Rationale:** The current per-operation transaction model is the single largest bottleneck for write performance. Batching multiple `put` operations into a single LMDB transaction dramatically reduces the number of disk syncs and transaction overhead.
    *   **Approach:** Introduce a `MetadataStore::put_batch(&self, metadata: &[ArtifactMetadata])` method. This method should open a single `write_txn`, iterate over the batch, perform all `put` operations within that transaction, and commit only once. For high-throughput scenarios, consider an internal buffer in `ArtifactWriter` that flushes to the `MetadataStore` in batches of 1,000 to 10,000 records.

2.  **Optimize Metadata Serialization**
    *   **Rationale:** Replacing `serde_json` with a more efficient binary serialization format will reduce the size of the metadata stored in LMDB and decrease the CPU time spent on serialization/deserialization.
    *   **Approach:** Switch the serialization for `ArtifactMetadata` and `ArtifactLocation` from `serde_json` to **`rkyv`** (already used in the project for artifacts) or **`postcard`**. `rkyv` offers zero-copy deserialization, which is ideal for read-heavy metadata lookups. This requires updating the `heed::types::Bytes` usage in `MetadataStore` to the new binary format.

3.  **Expose and Tune LMDB Configuration**
    *   **Rationale:** The hardcoded 10 GB `map_size` is a limitation. Exposing this and other LMDB parameters allows for environment-specific tuning, which is critical for scaling.
    *   **Approach:** Add `lmdb_map_size` (e.g., `u64`) to `ObfsConfig` in `/home/ubuntu/quant_b3_backtest/crates/obfs/src/lib.rs`. Use this value in `MetadataStore::open` (`/home/ubuntu/quant_b3_backtest/crates/obfs/src/store/mod.rs:31`). Also, consider adding an option to use `MDB_NOSYNC` for temporary, non-critical metadata writes, provided the risk of data loss on crash is acceptable for intermediate backtest results.

4.  **Evaluate Alternative Storage Backends (Redb)**
    *   **Rationale:** While LMDB is fast, it is a C library wrapper. A pure-Rust alternative like **`redb`** offers comparable performance, a safer API, and better integration with the Rust ecosystem, potentially simplifying maintenance and avoiding C-interop overhead.
    *   **Approach:** Create a feature flag and a parallel implementation of `MetadataStore` using `redb`. Benchmark the bulk-write and random-read performance against the current LMDB/Heed implementation using the existing `read_write_benchmark.rs` to validate the performance gain.

5.  **Increase Default Zstd Compression Level**
    *   **Rationale:** The default level 3 is fast but leaves significant compression ratio on the table. Higher compression reduces disk I/O, which is often the primary bottleneck for large-scale backtesting.
    *   **Approach:** Change the default `compression_level` in `ObfsConfig::default()` (`/home/ubuntu/quant_b3_backtest/crates/obfs/src/lib.rs:74`) from 3 to a higher, balanced level like 10 or 12, or even default to the `ULTRA_COMPRESSION_LEVEL` (19) if the CPU overhead is acceptable for the expected I/O savings.

## Performance Impact Estimate

The following table estimates the quantitative performance improvements from the proposed optimizations, focusing on the metadata write path, which is critical for the strategy generation phase.

| Optimization | Expected Speedup | Confidence | Measurement Method |
| :--- | :--- | :--- | :--- |
| Write Batching (Metadata) | 10x - 50x | High | Micro-benchmark of `put_batch` vs. sequential `put` for 10,000 records. |
| Serialization (JSON to rkyv/postcard) | 1.5x - 3x | Medium | Profiling CPU time spent in `serde_json::to_vec` vs. `rkyv::to_bytes`. |
| Alternative Backend (Redb) | 1.2x - 2x | Medium | Full system benchmark (e.g., `read_write_benchmark.rs`) comparison. |
| Zstd Compression Level (3 to 12) | 1.1x - 1.5x (I/O) | High | Measure total I/O time for reading/writing a large artifact set. |

## Implementation Complexity Assessment

The complexity of implementation varies significantly, with the greatest impact coming from the most complex change (Write Batching).

| Optimization | Effort (Low/Medium/High) | Risk | Dependencies |
| :--- | :--- | :--- | :--- |
| Write Batching (Metadata) | Medium | Low | Requires refactoring `ArtifactWriter` and `MetadataStore`. |
| Serialization (JSON to rkyv/postcard) | Medium | Medium | Requires updating all structs that use `serde_json` for LMDB storage. |
| LMDB Configuration Tuning | Low | Low | Simple change to `ObfsConfig` and `MetadataStore::open`. |
| Alternative Backend (Redb) | High | High | Requires parallel implementation and extensive testing to ensure data integrity. |
| Zstd Compression Level | Low | Low | Simple configuration change. |

## Trade-offs and Risks

### Trade-off: Write Performance vs. Data Durability (Write Batching)

*   **Description:** Implementing write batching inherently means that data is only persisted to disk when the batch is committed, not after every single write. In the event of a system crash, all uncommitted metadata within the current batch will be lost.
*   **Mitigation:** The backtesting system should be designed to tolerate the loss of intermediate, uncommitted metadata. For critical final results, ensure the batch is flushed and committed immediately. The `ArtifactWriter` should expose a `flush()` method that forces a transaction commit.

### Trade-off: Serialization Speed vs. Readability/Flexibility (rkyv/Postcard)

*   **Description:** Switching from human-readable JSON to a compact binary format like `rkyv` or `postcard` makes the LMDB data files opaque and difficult to inspect manually for debugging purposes.
*   **Mitigation:** Maintain robust unit and integration tests for the serialization/deserialization logic. Implement a small command-line utility within the `obfs` crate to read and pretty-print the binary metadata from the LMDB file for diagnostic purposes.

### Trade-off: LMDB vs. Alternative Backend (Redb/RocksDB)

*   **Description:** Migrating to an alternative backend like `redb` or `RocksDB` introduces a significant development and testing overhead. While `redb` is pure Rust, `RocksDB` (LSM-tree) has different performance characteristics (better write throughput, higher read latency) and is a C++ dependency, which complicates the build process.
*   **Mitigation:** Prioritize the pure-Rust `redb` for evaluation to maintain the project's Rust-native focus. Only consider `RocksDB` if `redb` fails to provide the necessary performance gains after all other LMDB optimizations (batching, serialization) have been applied. The current LMDB implementation should be retained as the stable default until the alternative is proven superior and stable.

## References

[1] https://www.reddit.com/r/rust/comments/1dsmj9d/embedded_keyvalue_database_2024/ - Embedded Key-value database - 2024.
[2] https://redb.org/post/2023/06/16/1-0-stable-release/ - redb 1.0 release announcement.
[3] https://stackoverflow.com/questions/31649216/writing-data-to-lmdb-with-python-very-slow - Discussion on slow LMDB writes due to lack of batching.
[4] https://groups.google.com/g/caffe-users/c/0RKsTTYRGpQ - Discussion on LMDB map_size tuning.
[5] https://docs.rs/heed - Documentation for the `heed` Rust wrapper for LMDB.
