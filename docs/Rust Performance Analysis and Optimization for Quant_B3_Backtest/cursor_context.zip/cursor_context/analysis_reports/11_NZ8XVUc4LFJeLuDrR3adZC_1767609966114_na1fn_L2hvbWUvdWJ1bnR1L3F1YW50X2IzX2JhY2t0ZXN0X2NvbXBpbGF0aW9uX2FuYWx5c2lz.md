# Compilation and Linking Optimization Opportunities in quant_b3_backtest

## Executive Summary

The `quant_b3_backtest` project has already implemented a highly aggressive compilation strategy, utilizing **Fat Link-Time Optimization (LTO)** and a **single codegen unit** in its `release` and `ultra` profiles. This addresses the most fundamental cross-module optimization opportunities. To achieve the ambitious goal of a **1000x performance improvement**, the focus must shift to **Profile-Guided Optimization (PGO)** and **CPU-specific instruction set tuning**. These two techniques represent the largest remaining gains from the compilation stage, as they allow the compiler to optimize the binary based on real-world execution flow and the specific capabilities of the target hardware.

## Key Findings

The analysis of `quant_b3_backtest/Cargo.toml` reveals a strong existing foundation for performance, but also highlights critical missing elements:

*   **Aggressive LTO and Codegen Settings:** The `release` and `ultra` profiles in `quant_b3_backtest/Cargo.toml` (lines 80-81, 106-107) already employ the most aggressive link-time optimization (`lto = "fat"`) and single codegen unit (`codegen-units = 1`), indicating a strong existing focus on final binary performance.
*   **Missing Profile-Guided Optimization (PGO):** No PGO configuration was found in the `Cargo.toml` profiles, representing the largest untapped compilation optimization for a performance-critical application with predictable hot paths.
*   **Generic CPU Target:** The compilation is likely targeting a generic CPU baseline, as no explicit `-C target-cpu` flag is set in `quant_b3_backtest/Cargo.toml`, potentially leaving significant SIMD and instruction set optimizations on the table, especially given the use of the `wide` crate.
*   **Panic Strategy for Performance:** The use of `panic = "abort"` in `quant_b3_backtest/Cargo.toml` (lines 82, 108) for `release` and `ultra` profiles correctly eliminates unwinding metadata, contributing to smaller and faster binaries.
*   **Benchmarking Profile for Profiling:** The `bench` profile in `quant_b3_backtest/Cargo.toml` (lines 90-93) is correctly configured with `debug = true` and `strip = "none"`, which is essential for accurate performance profiling and flamegraph generation.

## Optimization Opportunities

| # | Optimization | Rationale | Approach |
| :--- | :--- | :--- | :--- |
| 1 | **Profile-Guided Optimization (PGO)** | PGO allows the compiler to optimize based on real-world execution profiles, leading to better inlining, register allocation, and code layout for the backtester's highly predictable hot loops (e.g., in `backtester_engine`). | Implement a two-stage build process using the unstable `cargo-pgo` tool or manual setup with `RUSTFLAGS="-C profile-generate"` and `RUSTFLAGS="-C profile-use"`. This should be integrated into the CI/CD pipeline for the `ultra` profile. |
| 2 | **Specify Target CPU (`-C target-cpu=native`)** | Explicitly setting the target CPU to the host machine's architecture (`native`) or a modern common denominator (e.g., `skylake`, `znver3`) enables advanced instruction sets like AVX2 and AVX-512. This is critical for maximizing the performance of the existing `wide` (SIMD) usage. | Add `rustflags = ["-C", "target-cpu=native"]` to the `[profile.ultra]` section in `quant_b3_backtest/Cargo.toml`. For distribution, a build matrix targeting common architectures should be considered. |
| 3 | **Evaluate Thin LTO for Iteration Speed** | While `fat` LTO is used for the final binary, **Thin LTO** offers a superior trade-off between optimization quality and compilation time. For developers, a new profile (`release-thin`) using `lto = "thin"` and `codegen-units = 8` could significantly reduce build times without sacrificing too much optimization, improving the development feedback loop. | Introduce a new `[profile.release-thin]` in `quant_b3_backtest/Cargo.toml` with `lto = "thin"` and a higher `codegen-units` value. |

## Performance Impact Estimate

The following table estimates the potential performance gains from the proposed compilation and linking optimizations. These gains are multiplicative with existing architectural and algorithmic optimizations.

| Optimization | Expected Speedup | Confidence | Measurement Method |
| :--- | :--- | :--- | :--- |
| Profile-Guided Optimization (PGO) | 5% - 15% | High | Benchmark the core `backtester_engine` hot path using the `bench` profile before and after PGO. |
| Target CPU Optimization (`-C target-cpu=native`) | 10% - 30% | High | Benchmark SIMD-heavy operations (e.g., in `wide` usage) on a modern CPU, comparing generic vs. native target builds. |
| LTO Tuning (Thin LTO) | N/A (Compilation Time) | High | Measure full clean build time for the workspace using `fat` LTO vs. `thin` LTO profiles. |

## Implementation Complexity

| Optimization | Effort (Low/Medium/High) | Risk | Dependencies |
| :--- | :--- | :--- | :--- |
| Profile-Guided Optimization (PGO) | Medium | Medium | Requires a stable, representative workload for profiling; dependency on unstable Rust features or external tools (`cargo-pgo`). |
| Target CPU Optimization (`-C target-cpu=native`) | Low | Low | Requires the final execution environment to match the compilation environment (or a compatible one). Can be mitigated by targeting a specific, widely-used modern CPU. |
| LTO Tuning (Thin LTO) | Low | Low | No runtime risk; only affects compilation time and final binary size/performance (slightly lower than `fat` LTO). |

## Trade-offs and Risks

### Profile-Guided Optimization (PGO) Trade-offs

PGO offers significant performance gains but introduces complexity into the build process.

*   **Trade-off:** **Increased Build Complexity and Time.** PGO requires two full compilation passes (instrumentation and final optimization) plus a profiling run, significantly increasing the total time required to produce the final `ultra` binary.
*   **Mitigation:** **Automate and Isolate.** The PGO process should be fully automated within the CI/CD pipeline and only run for the final, production-ready `ultra` profile. Developers should continue to use the standard `release` or `release-thin` profiles for daily builds.

### Target CPU Optimization Trade-offs

Using `-C target-cpu=native` maximizes performance but sacrifices portability.

*   **Trade-off:** **Reduced Binary Portability.** A binary compiled with `target-cpu=native` will only run on machines with the exact same or a compatible CPU instruction set. For example, a binary compiled on a machine with AVX-512 will crash on an older machine that only supports AVX2.
*   **Mitigation:** **Target a Common Baseline or Distribute Multiple Binaries.**
    1.  **Target Baseline:** Use a specific, widely-adopted modern CPU target (e.g., `skylake` or `znver3`) that supports a good set of modern instructions (like AVX2) but is common enough to run on most modern servers.
    2.  **Multiple Binaries:** Distribute separate binaries for different CPU architectures (e.g., `quant_b3_backtest-avx2`, `quant_b3_backtest-avx512`) or use runtime CPU feature detection (though this is more complex to implement in Rust).

### Link-Time Optimization (LTO) Trade-offs

The existing use of `lto = "fat"` is the best choice for maximum performance, but it comes at a cost.

*   **Trade-off:** **Slow Compilation Time.** `lto = "fat"` combined with `codegen-units = 1` forces the compiler to analyze the entire program as a single unit, which is computationally expensive and slow, especially for a large workspace with 18 crates.
*   **Mitigation:** **Developer Profile Separation.** The introduction of a `release-thin` profile (using `lto = "thin"` and a higher `codegen-units`) allows developers to choose a faster, slightly less optimized build for rapid iteration, reserving the slow, maximally optimized `ultra` profile for final deployment.
