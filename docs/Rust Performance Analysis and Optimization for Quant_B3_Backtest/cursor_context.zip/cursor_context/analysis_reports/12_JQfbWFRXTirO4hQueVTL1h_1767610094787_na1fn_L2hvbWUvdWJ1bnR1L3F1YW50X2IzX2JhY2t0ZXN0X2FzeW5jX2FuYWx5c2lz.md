# Async/Await Potential for I/O-Bound Operations in `quant_b3_backtest`

## Executive Summary

This analysis evaluates the potential for further performance gains by integrating or optimizing `async/await` patterns, specifically with the `tokio` runtime, within the `quant_b3_backtest` repository. The codebase already employs highly optimized synchronous I/O (`memmap2`) and an existing `async` network client (`reqwest` within `brapi.rs`). The primary opportunity lies in creating a **hybrid sync/async architecture** to offload synchronous, CPU-intensive I/O parsing tasks to a dedicated thread pool, allowing the main backtesting loop to remain responsive and enabling concurrent loading of multiple data files. This approach is estimated to yield a **2x to 5x speedup** in the data loading phase, which is critical for the goal of achieving 1000x performance improvement for strategy generation.

## 1. Key Findings with Code Locations

The repository demonstrates a strong commitment to performance through existing optimizations (Rayon, SIMD, zero-alloc hot paths). The I/O-bound operations are split into two distinct categories:

*   **Highly Optimized Synchronous File I/O:** The data loading mechanism in `crates/backtester_io/src/mmap.rs` uses `memmap2` for zero-copy access to CSV files. This is excellent for sequential read performance. However, the initial line offset calculation (`MmapReader::open`, lines 32-37) and the subsequent line-by-line parsing (`MmapStream::next`, lines 212-236) are synchronous and block the thread.
    *   **File I/O Blocking:** `crates/backtester_io/src/mmap.rs`: The loop to pre-calculate line offsets is synchronous and can block the thread for large files.
    *   **Unnecessary Copy:** `crates/backtester_io/src/mmap.rs:222`: `let line_bytes = self.reader.get_line(self.current_line)?.to_vec();` involves a memory copy from the memory-mapped region, which negates the zero-copy benefit for the parsing step.
*   **Existing Asynchronous Network I/O:** The API client in `crates/market_data/src/brapi.rs` is already built on an `async/await` foundation using `reqwest` and `tokio::time::sleep` for rate limiting.
    *   **Existing Async:** `crates/market_data/src/brapi.rs:724`: The `async fn rate_limit(&self)` and `async fn request_with_retry` confirm the use of `tokio` and `async/await` for network operations.
    *   **Rate Limiting Blocking:** `crates/market_data/src/brapi.rs:725`: The `rate_limit` function uses a `std::sync::Mutex` to protect `last_request`, which can cause temporary blocking if contention occurs, although the subsequent `tokio::time::sleep` is non-blocking.
*   **Parallelism for CPU-Bound Work:** The `MmapStream::load_all` function (lines 198-209) loads all events into a vector, which is a common pattern before using `rayon` for parallel processing of the data. The synchronous parsing loop, however, must complete before Rayon can be fully utilized for the backtesting logic.

## 2. Concrete Optimization Opportunities

1.  **Hybrid Async/Sync Data Loading with `tokio::task::spawn_blocking`**
    *   **Rationale:** The file I/O and parsing are inherently CPU-bound and synchronous. Wrapping these operations in `tokio::task::spawn_blocking` allows the main `tokio` executor to handle concurrent network I/O (API calls) and other non-blocking tasks while the data loading runs on a dedicated thread pool. This prevents I/O-bound tasks from blocking the entire runtime.
    *   **Approach:** Refactor `MmapReader::open` and the `MmapStream` iteration to be called from within `spawn_blocking`. This is crucial for concurrent loading of multiple data files (e.g., one file per asset).

2.  **Concurrent Multi-File Data Loading**
    *   **Rationale:** The backtesting engine likely loads data for multiple assets. By making the data loading for each asset concurrent, the total time spent in the data preparation phase can be drastically reduced.
    *   **Approach:** In the calling code (e.g., `backtest_loader.rs`), use `tokio::join!` or `futures::future::join_all` to concurrently execute multiple `MmapStream::open` calls (each wrapped in `spawn_blocking`).

3.  **Zero-Copy Parsing Refinement**
    *   **Rationale:** The `to_vec()` call in `MmapStream::next` (line 222) creates a copy of the line data, which is inefficient for large datasets.
    *   **Approach:** Modify `MmapStream::parse_line` to accept a reference to the memory-mapped slice (`&[u8]`) and ensure the parsing logic (especially the fast timestamp parser) operates directly on the slice without allocation. The `MmapStream`'s `Iterator` implementation should be refactored to avoid the copy.

4.  **Asynchronous API Call Batching and Concurrency**
    *   **Rationale:** While the `brapi.rs` client is async, the caller must ensure that requests for multiple tickers are executed concurrently to maximize throughput, especially when fetching historical data.
    *   **Approach:** Review the data ingestion logic in `market_data` (e.g., `ingest.rs` or `backtest_loader.rs`) to ensure that API calls for different tickers are batched and executed in parallel using `futures::future::join_all` instead of sequential `await` calls.

## 3. Quantitative Performance Impact Estimate

| Optimization | Expected Speedup | Confidence | Measurement Method |
| :--- | :--- | :--- | :--- |
| Concurrent Multi-File Data Loading | 2x - 5x | High | Benchmark total time to load 100 data files concurrently vs. sequentially. |
| Hybrid Async/Sync Data Parsing | 1.2x - 1.5x | Medium | Profile `MmapStream::next` and `MmapReader::open` before and after `spawn_blocking` integration. |
| Zero-Copy Parsing Refinement | 1.1x - 1.3x | Medium | Micro-benchmark `MmapStream::next` with and without the `to_vec()` copy. |
| Async API Call Concurrency | 3x - 10x | High | Benchmark total time to fetch data for 50 tickers concurrently vs. sequentially (limited by API rate limit). |

## 4. Implementation Complexity Assessment

| Optimization | Effort (Low/Medium/High) | Risk | Dependencies |
| :--- | :--- | :--- | :--- |
| Concurrent Multi-File Data Loading | Medium | Low | `tokio` (already present), `futures` crate. |
| Hybrid Async/Sync Data Parsing | Medium | Medium | `tokio::task::spawn_blocking`. Requires careful management of thread-safe data access. |
| Zero-Copy Parsing Refinement | Low | Low | None. Pure refactoring of `MmapStream` and `parse_line`. |
| Async API Call Concurrency | Low | Low | None. Refactoring of the calling code in `market_data` crate. |

## 5. Trade-offs and Risks

### Trade-off: Increased Code Complexity and Runtime Overhead
Integrating `async/await` introduces the complexity of managing futures, executors, and the distinction between `async` and synchronous code. The hybrid approach using `spawn_blocking` adds the overhead of thread-switching.

*   **Mitigation:** Clearly define the boundaries between the synchronous (CPU-bound backtesting core) and the asynchronous (I/O-bound data loading/API) parts of the application. Use dedicated crates for each domain to maintain separation of concerns.

### Trade-off: Potential for Blocking in Async Context
If synchronous code is accidentally executed on the main `tokio` executor (e.g., forgetting to use `spawn_blocking` for file I/O), it will block the entire runtime, leading to performance degradation and poor API responsiveness.

*   **Mitigation:** Enforce strict code review to ensure all synchronous I/O or CPU-intensive loops are wrapped in `tokio::task::spawn_blocking`. Use static analysis tools (if available) to detect common blocking patterns in `async` functions.

### Risk: Data Race Conditions in Hybrid Architecture
Moving data loading to a separate thread pool via `spawn_blocking` requires careful handling of shared state, such as the `Normalizer` in `MmapStream`.

*   **Mitigation:** Ensure all data passed between the synchronous worker threads and the main async task is either owned (moved) or protected by appropriate synchronization primitives (`Arc`, `Mutex`, or `RwLock`). The `Normalizer` should be cloned or protected if accessed concurrently.

### Risk: Diminishing Returns from `memmap2`
The existing `memmap2` is already highly efficient. Introducing `async` overhead might not yield significant gains if the I/O bottleneck is primarily the CPU-bound parsing, which is still synchronous even when offloaded.

*   **Mitigation:** Prioritize the **Concurrent Multi-File Data Loading** and **Async API Call Concurrency** optimizations, as these address true concurrency bottlenecks. Measure the performance impact of the `spawn_blocking` refactoring carefully to ensure a net positive gain.
