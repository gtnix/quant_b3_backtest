# GPU Acceleration Opportunities in quant_b3_backtest: NSGA-II and Matrix Operations

## Executive Summary

This analysis investigates opportunities for GPU acceleration within the `quant_b3_backtest` repository, focusing on achieving the ambitious goal of a **1000x performance improvement** for strategy generation. The primary bottlenecks identified are the $O(N^2)$ complexity of the Non-dominated Sorting Genetic Algorithm II (NSGA-II) core and large-scale matrix operations, such as Correlation Matrix calculation.

The recommendation is a hybrid approach: leveraging **`rust-cuda`** for the most extreme performance gains in the NSGA-II core, and utilizing **`wgpu`** for portable, cross-platform acceleration of linear algebra tasks. This strategy targets the most critical hot paths with the highest-performance tool available, while maintaining a degree of future-proofing for other components.

## Key Findings

The following are the specific compute-intensive operations identified as prime candidates for GPU offloading:

*   The most compute-intensive operation is the Non-dominated Sorting Genetic Algorithm II (NSGA-II) core loop, which is central to the `combiner_engine`. The dominance comparison is an $O(N^2)$ operation, making it the primary bottleneck for large populations. (`/home/ubuntu/quant_b3_backtest/crates/combiner_engine/src/pareto_simd.rs`)
*   The NSGA-II core is already partially optimized using SIMD (`wide::f64x4`) for dominance comparison, indicating a strong existing focus on high-performance optimization. (`/home/ubuntu/quant_b3_backtest/crates/combiner_engine/src/pareto_simd.rs`)
*   The `compute_dominance_simd` function, which performs the pairwise dominance checks, is highly parallelizable and an ideal candidate for fine-grained GPU thread execution. (`/home/ubuntu/quant_b3_backtest/crates/combiner_engine/src/pareto_simd.rs`)
*   The `compute_crowding_distance_simd` function, which involves sorting and distance calculation per objective, is also a highly parallelizable component of the NSGA-II algorithm. (`/home/ubuntu/quant_b3_backtest/crates/combiner_engine/src/pareto_simd.rs`)
*   Correlation Matrix calculation, a standard linear algebra operation, is a secondary, but still significant, opportunity, as evidenced by its use in the `dashboard` and `market_data` crates. (`/home/ubuntu/quant_b3_backtest/dashboard/src/components/charts/CorrelationMatrix.tsx`)
*   The project's existing use of `rayon`, `wide`, and `memmap2` confirms a strong existing commitment to high-performance, justifying the aggressive GPU acceleration approach.

## Optimization Opportunities

1.  **NSGA-II Core Offloading (rust-cuda):**
    *   **Rationale:** The $O(N^2)$ complexity of non-dominated sorting is the primary bottleneck. Achieving a 1000x speedup requires a massive increase in parallel throughput, which is best delivered by a native CUDA implementation.
    *   **Approach:** Migrate the core logic of `compute_dominance_simd` and `compute_crowding_distance_simd` to `rust-cuda` kernels. This involves rewriting the inner loops to execute as thousands of parallel threads on the GPU, specifically targeting the pairwise comparisons. The CPU will manage data transfer and kernel launch.

2.  **Correlation Matrix Calculation (wgpu):**
    *   **Rationale:** Correlation matrix calculation is a standard, dense linear algebra operation that benefits significantly from GPU parallelism. Using `wgpu` provides cross-platform compatibility (Vulkan, Metal, DX12) for the linear algebra utility layer, which is crucial for a potentially user-facing component like the dashboard.
    *   **Approach:** Introduce a new crate, e.g., `backtester_linalg_gpu`, that implements the matrix multiplication and reduction steps required for correlation using `wgpu` compute shaders (WGSL). This crate would be called by `backtester_intelligence` or `market_data` for large datasets.

3.  **Monte Carlo Simulation Acceleration (wgpu/rust-cuda):**
    *   **Rationale:** While not explicitly found, Monte Carlo simulations (if used for pricing or risk) are "embarrassingly parallel" and a classic GPU use case. The existing architecture is well-suited to integrate this.
    *   **Approach:** Implement a Monte Carlo path generation and aggregation kernel using `wgpu` (for portability) or `rust-cuda` (for max speed). The large number of independent paths can be mapped directly to GPU threads.

## Quantitative Performance Impact Estimate

| Optimization | Expected Speedup | Confidence | Measurement Method |
| :--- | :--- | :--- | :--- |
| NSGA-II Core Offloading (rust-cuda) | 500x - 1500x | High | Micro-benchmarking of kernel execution time vs. current SIMD/CPU time for $N \ge 10,000$ |
| Correlation Matrix (wgpu) | 50x - 200x | Medium | End-to-end timing of matrix calculation for $N \ge 1,000$ time series, comparing CPU vs. GPU execution |
| Monte Carlo Simulation (wgpu/rust-cuda) | 100x - 1000x | High | Path generation throughput (paths/second) comparison between CPU and GPU implementations |

## Implementation Complexity Assessment

| Optimization | Effort (Low/Medium/High) | Risk | Dependencies |
| :--- | :--- | :--- | :--- |
| NSGA-II Core Offloading (rust-cuda) | High | High | `rust-cuda`, NVIDIA driver/toolkit, `unsafe` Rust code |
| Correlation Matrix (wgpu) | Medium | Medium | `wgpu`, WGSL compute shaders, data transfer management |
| Monte Carlo Simulation (wgpu/rust-cuda) | Medium | Medium | `wgpu` or `rust-cuda`, new crate for simulation logic |

## Trade-offs and Risks

### 1. Vendor Lock-in and Portability

The choice of **`rust-cuda`** for the critical NSGA-II component introduces a hard dependency on NVIDIA hardware and the CUDA ecosystem. This directly conflicts with the general desire for cross-platform compatibility.

*   **Mitigation Approach:** Encapsulate all `rust-cuda` logic within a dedicated feature-gated crate (e.g., `combiner_engine_cuda`). Maintain the existing SIMD/CPU implementation as a fallback. This allows the core logic to be compiled for non-NVIDIA environments, albeit with lower performance.

### 2. Implementation Complexity and Safety

Both `rust-cuda` and writing `wgpu` compute shaders require a significant shift from idiomatic Rust, involving manual memory management, explicit data transfer between host and device, and potentially extensive use of `unsafe` blocks for `rust-cuda`. This increases the risk of bugs and memory errors.

*   **Mitigation Approach:** Implement a robust testing harness that validates GPU kernel output against the existing, proven CPU/SIMD implementation. Use Rust's type system to enforce safe data transfer wrappers where possible. Prioritize small, verifiable kernels over large, monolithic ones.

### 3. Data Transfer Overhead

The performance gains from GPU acceleration can be negated if the time spent transferring data between the CPU (host) and the GPU (device) exceeds the time saved by the parallel computation. This is a common pitfall in GPGPU.

*   **Mitigation Approach:** Implement a strategy of **"data locality"** where large datasets (e.g., historical market data, large population arrays) are transferred to the GPU once and kept there for multiple generations/iterations of the genetic algorithm. Only the final results and small configuration updates should be transferred back to the CPU. This is especially critical for the NSGA-II loop.

### 4. Diminishing Returns on Smaller Datasets

GPU acceleration typically only provides a benefit for large problem sizes ($N$). For small population sizes or short backtests, the overhead of kernel launch and data transfer will make the GPU implementation slower than the existing highly-optimized CPU/SIMD code.

*   **Mitigation Approach:** Implement a runtime heuristic within the `combiner_engine` that checks the population size ($N$) and dynamically selects between the existing SIMD implementation (for $N < N_{threshold}$) and the new GPU implementation (for $N \ge N_{threshold}$). The threshold $N_{threshold}$ must be determined via rigorous benchmarking.
